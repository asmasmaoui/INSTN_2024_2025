/**
 */
package SimpleNN;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>LSTM</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link SimpleNN.LSTM#isUseBias <em>Use Bias</em>}</li>
 *   <li>{@link SimpleNN.LSTM#getActivationFct <em>Activation Fct</em>}</li>
 * </ul>
 *
 * @see SimpleNN.SimpleNNPackage#getLSTM()
 * @model
 * @generated
 */
public interface LSTM extends Layer {
	/**
	 * Returns the value of the '<em><b>Use Bias</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Use Bias</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Use Bias</em>' attribute.
	 * @see #setUseBias(boolean)
	 * @see SimpleNN.SimpleNNPackage#getLSTM_UseBias()
	 * @model dataType="org.eclipse.uml2.types.Boolean" ordered="false"
	 * @generated
	 */
	boolean isUseBias();

	/**
	 * Sets the value of the '{@link SimpleNN.LSTM#isUseBias <em>Use Bias</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Use Bias</em>' attribute.
	 * @see #isUseBias()
	 * @generated
	 */
	void setUseBias(boolean value);

	/**
	 * Returns the value of the '<em><b>Activation Fct</b></em>' attribute.
	 * The literals are from the enumeration {@link SimpleNN.EActivationFCT}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Activation Fct</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Activation Fct</em>' attribute.
	 * @see SimpleNN.EActivationFCT
	 * @see #setActivationFct(EActivationFCT)
	 * @see SimpleNN.SimpleNNPackage#getLSTM_ActivationFct()
	 * @model ordered="false"
	 * @generated
	 */
	EActivationFCT getActivationFct();

	/**
	 * Sets the value of the '{@link SimpleNN.LSTM#getActivationFct <em>Activation Fct</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Activation Fct</em>' attribute.
	 * @see SimpleNN.EActivationFCT
	 * @see #getActivationFct()
	 * @generated
	 */
	void setActivationFct(EActivationFCT value);

} // LSTM
