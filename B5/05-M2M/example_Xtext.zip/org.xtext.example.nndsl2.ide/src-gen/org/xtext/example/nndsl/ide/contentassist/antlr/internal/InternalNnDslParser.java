package org.xtext.example.nndsl.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.xtext.example.nndsl.services.NnDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalNnDslParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INT", "RULE_ACTIVATION", "RULE_BOOLEAN", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'network'", "'{'", "'}'", "':'", "'Conv'", "'LSTM'", "'('", "')'", "','", "'kernel_size'", "'='", "'filters'", "'activation'", "'use_bias'"
    };
    public static final int RULE_BOOLEAN=7;
    public static final int RULE_STRING=8;
    public static final int RULE_SL_COMMENT=10;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ACTIVATION=6;
    public static final int RULE_ID=4;
    public static final int RULE_WS=11;
    public static final int RULE_ANY_OTHER=12;
    public static final int T__26=26;
    public static final int RULE_INT=5;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=9;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalNnDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalNnDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalNnDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalNnDsl.g"; }


    	private NnDslGrammarAccess grammarAccess;

    	public void setGrammarAccess(NnDslGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleModel"
    // InternalNnDsl.g:53:1: entryRuleModel : ruleModel EOF ;
    public final void entryRuleModel() throws RecognitionException {
        try {
            // InternalNnDsl.g:54:1: ( ruleModel EOF )
            // InternalNnDsl.g:55:1: ruleModel EOF
            {
             before(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            ruleModel();

            state._fsp--;

             after(grammarAccess.getModelRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalNnDsl.g:62:1: ruleModel : ( ( rule__Model__Group__0 ) ) ;
    public final void ruleModel() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:66:2: ( ( ( rule__Model__Group__0 ) ) )
            // InternalNnDsl.g:67:2: ( ( rule__Model__Group__0 ) )
            {
            // InternalNnDsl.g:67:2: ( ( rule__Model__Group__0 ) )
            // InternalNnDsl.g:68:3: ( rule__Model__Group__0 )
            {
             before(grammarAccess.getModelAccess().getGroup()); 
            // InternalNnDsl.g:69:3: ( rule__Model__Group__0 )
            // InternalNnDsl.g:69:4: rule__Model__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Model__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleLayer"
    // InternalNnDsl.g:78:1: entryRuleLayer : ruleLayer EOF ;
    public final void entryRuleLayer() throws RecognitionException {
        try {
            // InternalNnDsl.g:79:1: ( ruleLayer EOF )
            // InternalNnDsl.g:80:1: ruleLayer EOF
            {
             before(grammarAccess.getLayerRule()); 
            pushFollow(FOLLOW_1);
            ruleLayer();

            state._fsp--;

             after(grammarAccess.getLayerRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLayer"


    // $ANTLR start "ruleLayer"
    // InternalNnDsl.g:87:1: ruleLayer : ( ( rule__Layer__Group__0 ) ) ;
    public final void ruleLayer() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:91:2: ( ( ( rule__Layer__Group__0 ) ) )
            // InternalNnDsl.g:92:2: ( ( rule__Layer__Group__0 ) )
            {
            // InternalNnDsl.g:92:2: ( ( rule__Layer__Group__0 ) )
            // InternalNnDsl.g:93:3: ( rule__Layer__Group__0 )
            {
             before(grammarAccess.getLayerAccess().getGroup()); 
            // InternalNnDsl.g:94:3: ( rule__Layer__Group__0 )
            // InternalNnDsl.g:94:4: rule__Layer__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Layer__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getLayerAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLayer"


    // $ANTLR start "entryRuleLayerInfo"
    // InternalNnDsl.g:103:1: entryRuleLayerInfo : ruleLayerInfo EOF ;
    public final void entryRuleLayerInfo() throws RecognitionException {
        try {
            // InternalNnDsl.g:104:1: ( ruleLayerInfo EOF )
            // InternalNnDsl.g:105:1: ruleLayerInfo EOF
            {
             before(grammarAccess.getLayerInfoRule()); 
            pushFollow(FOLLOW_1);
            ruleLayerInfo();

            state._fsp--;

             after(grammarAccess.getLayerInfoRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLayerInfo"


    // $ANTLR start "ruleLayerInfo"
    // InternalNnDsl.g:112:1: ruleLayerInfo : ( ( rule__LayerInfo__Alternatives ) ) ;
    public final void ruleLayerInfo() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:116:2: ( ( ( rule__LayerInfo__Alternatives ) ) )
            // InternalNnDsl.g:117:2: ( ( rule__LayerInfo__Alternatives ) )
            {
            // InternalNnDsl.g:117:2: ( ( rule__LayerInfo__Alternatives ) )
            // InternalNnDsl.g:118:3: ( rule__LayerInfo__Alternatives )
            {
             before(grammarAccess.getLayerInfoAccess().getAlternatives()); 
            // InternalNnDsl.g:119:3: ( rule__LayerInfo__Alternatives )
            // InternalNnDsl.g:119:4: rule__LayerInfo__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__LayerInfo__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getLayerInfoAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLayerInfo"


    // $ANTLR start "entryRuleCOptions"
    // InternalNnDsl.g:128:1: entryRuleCOptions : ruleCOptions EOF ;
    public final void entryRuleCOptions() throws RecognitionException {
        try {
            // InternalNnDsl.g:129:1: ( ruleCOptions EOF )
            // InternalNnDsl.g:130:1: ruleCOptions EOF
            {
             before(grammarAccess.getCOptionsRule()); 
            pushFollow(FOLLOW_1);
            ruleCOptions();

            state._fsp--;

             after(grammarAccess.getCOptionsRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCOptions"


    // $ANTLR start "ruleCOptions"
    // InternalNnDsl.g:137:1: ruleCOptions : ( ( rule__COptions__Group__0 ) ) ;
    public final void ruleCOptions() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:141:2: ( ( ( rule__COptions__Group__0 ) ) )
            // InternalNnDsl.g:142:2: ( ( rule__COptions__Group__0 ) )
            {
            // InternalNnDsl.g:142:2: ( ( rule__COptions__Group__0 ) )
            // InternalNnDsl.g:143:3: ( rule__COptions__Group__0 )
            {
             before(grammarAccess.getCOptionsAccess().getGroup()); 
            // InternalNnDsl.g:144:3: ( rule__COptions__Group__0 )
            // InternalNnDsl.g:144:4: rule__COptions__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__COptions__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getCOptionsAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCOptions"


    // $ANTLR start "entryRuleCOption"
    // InternalNnDsl.g:153:1: entryRuleCOption : ruleCOption EOF ;
    public final void entryRuleCOption() throws RecognitionException {
        try {
            // InternalNnDsl.g:154:1: ( ruleCOption EOF )
            // InternalNnDsl.g:155:1: ruleCOption EOF
            {
             before(grammarAccess.getCOptionRule()); 
            pushFollow(FOLLOW_1);
            ruleCOption();

            state._fsp--;

             after(grammarAccess.getCOptionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCOption"


    // $ANTLR start "ruleCOption"
    // InternalNnDsl.g:162:1: ruleCOption : ( ( rule__COption__Alternatives ) ) ;
    public final void ruleCOption() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:166:2: ( ( ( rule__COption__Alternatives ) ) )
            // InternalNnDsl.g:167:2: ( ( rule__COption__Alternatives ) )
            {
            // InternalNnDsl.g:167:2: ( ( rule__COption__Alternatives ) )
            // InternalNnDsl.g:168:3: ( rule__COption__Alternatives )
            {
             before(grammarAccess.getCOptionAccess().getAlternatives()); 
            // InternalNnDsl.g:169:3: ( rule__COption__Alternatives )
            // InternalNnDsl.g:169:4: rule__COption__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__COption__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getCOptionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCOption"


    // $ANTLR start "entryRuleLOptions"
    // InternalNnDsl.g:178:1: entryRuleLOptions : ruleLOptions EOF ;
    public final void entryRuleLOptions() throws RecognitionException {
        try {
            // InternalNnDsl.g:179:1: ( ruleLOptions EOF )
            // InternalNnDsl.g:180:1: ruleLOptions EOF
            {
             before(grammarAccess.getLOptionsRule()); 
            pushFollow(FOLLOW_1);
            ruleLOptions();

            state._fsp--;

             after(grammarAccess.getLOptionsRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLOptions"


    // $ANTLR start "ruleLOptions"
    // InternalNnDsl.g:187:1: ruleLOptions : ( ( rule__LOptions__Group__0 ) ) ;
    public final void ruleLOptions() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:191:2: ( ( ( rule__LOptions__Group__0 ) ) )
            // InternalNnDsl.g:192:2: ( ( rule__LOptions__Group__0 ) )
            {
            // InternalNnDsl.g:192:2: ( ( rule__LOptions__Group__0 ) )
            // InternalNnDsl.g:193:3: ( rule__LOptions__Group__0 )
            {
             before(grammarAccess.getLOptionsAccess().getGroup()); 
            // InternalNnDsl.g:194:3: ( rule__LOptions__Group__0 )
            // InternalNnDsl.g:194:4: rule__LOptions__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__LOptions__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getLOptionsAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLOptions"


    // $ANTLR start "entryRuleLOption"
    // InternalNnDsl.g:203:1: entryRuleLOption : ruleLOption EOF ;
    public final void entryRuleLOption() throws RecognitionException {
        try {
            // InternalNnDsl.g:204:1: ( ruleLOption EOF )
            // InternalNnDsl.g:205:1: ruleLOption EOF
            {
             before(grammarAccess.getLOptionRule()); 
            pushFollow(FOLLOW_1);
            ruleLOption();

            state._fsp--;

             after(grammarAccess.getLOptionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLOption"


    // $ANTLR start "ruleLOption"
    // InternalNnDsl.g:212:1: ruleLOption : ( ( rule__LOption__Alternatives ) ) ;
    public final void ruleLOption() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:216:2: ( ( ( rule__LOption__Alternatives ) ) )
            // InternalNnDsl.g:217:2: ( ( rule__LOption__Alternatives ) )
            {
            // InternalNnDsl.g:217:2: ( ( rule__LOption__Alternatives ) )
            // InternalNnDsl.g:218:3: ( rule__LOption__Alternatives )
            {
             before(grammarAccess.getLOptionAccess().getAlternatives()); 
            // InternalNnDsl.g:219:3: ( rule__LOption__Alternatives )
            // InternalNnDsl.g:219:4: rule__LOption__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__LOption__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getLOptionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLOption"


    // $ANTLR start "rule__LayerInfo__Alternatives"
    // InternalNnDsl.g:227:1: rule__LayerInfo__Alternatives : ( ( ( rule__LayerInfo__Group_0__0 ) ) | ( ( rule__LayerInfo__Group_1__0 ) ) );
    public final void rule__LayerInfo__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:231:1: ( ( ( rule__LayerInfo__Group_0__0 ) ) | ( ( rule__LayerInfo__Group_1__0 ) ) )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==17) ) {
                alt1=1;
            }
            else if ( (LA1_0==18) ) {
                alt1=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // InternalNnDsl.g:232:2: ( ( rule__LayerInfo__Group_0__0 ) )
                    {
                    // InternalNnDsl.g:232:2: ( ( rule__LayerInfo__Group_0__0 ) )
                    // InternalNnDsl.g:233:3: ( rule__LayerInfo__Group_0__0 )
                    {
                     before(grammarAccess.getLayerInfoAccess().getGroup_0()); 
                    // InternalNnDsl.g:234:3: ( rule__LayerInfo__Group_0__0 )
                    // InternalNnDsl.g:234:4: rule__LayerInfo__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__LayerInfo__Group_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getLayerInfoAccess().getGroup_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalNnDsl.g:238:2: ( ( rule__LayerInfo__Group_1__0 ) )
                    {
                    // InternalNnDsl.g:238:2: ( ( rule__LayerInfo__Group_1__0 ) )
                    // InternalNnDsl.g:239:3: ( rule__LayerInfo__Group_1__0 )
                    {
                     before(grammarAccess.getLayerInfoAccess().getGroup_1()); 
                    // InternalNnDsl.g:240:3: ( rule__LayerInfo__Group_1__0 )
                    // InternalNnDsl.g:240:4: rule__LayerInfo__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__LayerInfo__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getLayerInfoAccess().getGroup_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LayerInfo__Alternatives"


    // $ANTLR start "rule__COption__Alternatives"
    // InternalNnDsl.g:248:1: rule__COption__Alternatives : ( ( ( rule__COption__Group_0__0 ) ) | ( ( rule__COption__Group_1__0 ) ) );
    public final void rule__COption__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:252:1: ( ( ( rule__COption__Group_0__0 ) ) | ( ( rule__COption__Group_1__0 ) ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==22) ) {
                alt2=1;
            }
            else if ( (LA2_0==24) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalNnDsl.g:253:2: ( ( rule__COption__Group_0__0 ) )
                    {
                    // InternalNnDsl.g:253:2: ( ( rule__COption__Group_0__0 ) )
                    // InternalNnDsl.g:254:3: ( rule__COption__Group_0__0 )
                    {
                     before(grammarAccess.getCOptionAccess().getGroup_0()); 
                    // InternalNnDsl.g:255:3: ( rule__COption__Group_0__0 )
                    // InternalNnDsl.g:255:4: rule__COption__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__COption__Group_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getCOptionAccess().getGroup_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalNnDsl.g:259:2: ( ( rule__COption__Group_1__0 ) )
                    {
                    // InternalNnDsl.g:259:2: ( ( rule__COption__Group_1__0 ) )
                    // InternalNnDsl.g:260:3: ( rule__COption__Group_1__0 )
                    {
                     before(grammarAccess.getCOptionAccess().getGroup_1()); 
                    // InternalNnDsl.g:261:3: ( rule__COption__Group_1__0 )
                    // InternalNnDsl.g:261:4: rule__COption__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__COption__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getCOptionAccess().getGroup_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COption__Alternatives"


    // $ANTLR start "rule__LOption__Alternatives"
    // InternalNnDsl.g:269:1: rule__LOption__Alternatives : ( ( ( rule__LOption__Group_0__0 ) ) | ( ( rule__LOption__Group_1__0 ) ) );
    public final void rule__LOption__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:273:1: ( ( ( rule__LOption__Group_0__0 ) ) | ( ( rule__LOption__Group_1__0 ) ) )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==25) ) {
                alt3=1;
            }
            else if ( (LA3_0==26) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // InternalNnDsl.g:274:2: ( ( rule__LOption__Group_0__0 ) )
                    {
                    // InternalNnDsl.g:274:2: ( ( rule__LOption__Group_0__0 ) )
                    // InternalNnDsl.g:275:3: ( rule__LOption__Group_0__0 )
                    {
                     before(grammarAccess.getLOptionAccess().getGroup_0()); 
                    // InternalNnDsl.g:276:3: ( rule__LOption__Group_0__0 )
                    // InternalNnDsl.g:276:4: rule__LOption__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__LOption__Group_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getLOptionAccess().getGroup_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalNnDsl.g:280:2: ( ( rule__LOption__Group_1__0 ) )
                    {
                    // InternalNnDsl.g:280:2: ( ( rule__LOption__Group_1__0 ) )
                    // InternalNnDsl.g:281:3: ( rule__LOption__Group_1__0 )
                    {
                     before(grammarAccess.getLOptionAccess().getGroup_1()); 
                    // InternalNnDsl.g:282:3: ( rule__LOption__Group_1__0 )
                    // InternalNnDsl.g:282:4: rule__LOption__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__LOption__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getLOptionAccess().getGroup_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOption__Alternatives"


    // $ANTLR start "rule__Model__Group__0"
    // InternalNnDsl.g:290:1: rule__Model__Group__0 : rule__Model__Group__0__Impl rule__Model__Group__1 ;
    public final void rule__Model__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:294:1: ( rule__Model__Group__0__Impl rule__Model__Group__1 )
            // InternalNnDsl.g:295:2: rule__Model__Group__0__Impl rule__Model__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Model__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Model__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__0"


    // $ANTLR start "rule__Model__Group__0__Impl"
    // InternalNnDsl.g:302:1: rule__Model__Group__0__Impl : ( 'network' ) ;
    public final void rule__Model__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:306:1: ( ( 'network' ) )
            // InternalNnDsl.g:307:1: ( 'network' )
            {
            // InternalNnDsl.g:307:1: ( 'network' )
            // InternalNnDsl.g:308:2: 'network'
            {
             before(grammarAccess.getModelAccess().getNetworkKeyword_0()); 
            match(input,13,FOLLOW_2); 
             after(grammarAccess.getModelAccess().getNetworkKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__0__Impl"


    // $ANTLR start "rule__Model__Group__1"
    // InternalNnDsl.g:317:1: rule__Model__Group__1 : rule__Model__Group__1__Impl rule__Model__Group__2 ;
    public final void rule__Model__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:321:1: ( rule__Model__Group__1__Impl rule__Model__Group__2 )
            // InternalNnDsl.g:322:2: rule__Model__Group__1__Impl rule__Model__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__Model__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Model__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__1"


    // $ANTLR start "rule__Model__Group__1__Impl"
    // InternalNnDsl.g:329:1: rule__Model__Group__1__Impl : ( ( rule__Model__NameAssignment_1 ) ) ;
    public final void rule__Model__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:333:1: ( ( ( rule__Model__NameAssignment_1 ) ) )
            // InternalNnDsl.g:334:1: ( ( rule__Model__NameAssignment_1 ) )
            {
            // InternalNnDsl.g:334:1: ( ( rule__Model__NameAssignment_1 ) )
            // InternalNnDsl.g:335:2: ( rule__Model__NameAssignment_1 )
            {
             before(grammarAccess.getModelAccess().getNameAssignment_1()); 
            // InternalNnDsl.g:336:2: ( rule__Model__NameAssignment_1 )
            // InternalNnDsl.g:336:3: rule__Model__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Model__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__1__Impl"


    // $ANTLR start "rule__Model__Group__2"
    // InternalNnDsl.g:344:1: rule__Model__Group__2 : rule__Model__Group__2__Impl rule__Model__Group__3 ;
    public final void rule__Model__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:348:1: ( rule__Model__Group__2__Impl rule__Model__Group__3 )
            // InternalNnDsl.g:349:2: rule__Model__Group__2__Impl rule__Model__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__Model__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Model__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__2"


    // $ANTLR start "rule__Model__Group__2__Impl"
    // InternalNnDsl.g:356:1: rule__Model__Group__2__Impl : ( '{' ) ;
    public final void rule__Model__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:360:1: ( ( '{' ) )
            // InternalNnDsl.g:361:1: ( '{' )
            {
            // InternalNnDsl.g:361:1: ( '{' )
            // InternalNnDsl.g:362:2: '{'
            {
             before(grammarAccess.getModelAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getModelAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__2__Impl"


    // $ANTLR start "rule__Model__Group__3"
    // InternalNnDsl.g:371:1: rule__Model__Group__3 : rule__Model__Group__3__Impl rule__Model__Group__4 ;
    public final void rule__Model__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:375:1: ( rule__Model__Group__3__Impl rule__Model__Group__4 )
            // InternalNnDsl.g:376:2: rule__Model__Group__3__Impl rule__Model__Group__4
            {
            pushFollow(FOLLOW_5);
            rule__Model__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Model__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__3"


    // $ANTLR start "rule__Model__Group__3__Impl"
    // InternalNnDsl.g:383:1: rule__Model__Group__3__Impl : ( ( rule__Model__LayersAssignment_3 )* ) ;
    public final void rule__Model__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:387:1: ( ( ( rule__Model__LayersAssignment_3 )* ) )
            // InternalNnDsl.g:388:1: ( ( rule__Model__LayersAssignment_3 )* )
            {
            // InternalNnDsl.g:388:1: ( ( rule__Model__LayersAssignment_3 )* )
            // InternalNnDsl.g:389:2: ( rule__Model__LayersAssignment_3 )*
            {
             before(grammarAccess.getModelAccess().getLayersAssignment_3()); 
            // InternalNnDsl.g:390:2: ( rule__Model__LayersAssignment_3 )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==RULE_ID) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalNnDsl.g:390:3: rule__Model__LayersAssignment_3
            	    {
            	    pushFollow(FOLLOW_6);
            	    rule__Model__LayersAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

             after(grammarAccess.getModelAccess().getLayersAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__3__Impl"


    // $ANTLR start "rule__Model__Group__4"
    // InternalNnDsl.g:398:1: rule__Model__Group__4 : rule__Model__Group__4__Impl ;
    public final void rule__Model__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:402:1: ( rule__Model__Group__4__Impl )
            // InternalNnDsl.g:403:2: rule__Model__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Model__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__4"


    // $ANTLR start "rule__Model__Group__4__Impl"
    // InternalNnDsl.g:409:1: rule__Model__Group__4__Impl : ( '}' ) ;
    public final void rule__Model__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:413:1: ( ( '}' ) )
            // InternalNnDsl.g:414:1: ( '}' )
            {
            // InternalNnDsl.g:414:1: ( '}' )
            // InternalNnDsl.g:415:2: '}'
            {
             before(grammarAccess.getModelAccess().getRightCurlyBracketKeyword_4()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getModelAccess().getRightCurlyBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__4__Impl"


    // $ANTLR start "rule__Layer__Group__0"
    // InternalNnDsl.g:425:1: rule__Layer__Group__0 : rule__Layer__Group__0__Impl rule__Layer__Group__1 ;
    public final void rule__Layer__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:429:1: ( rule__Layer__Group__0__Impl rule__Layer__Group__1 )
            // InternalNnDsl.g:430:2: rule__Layer__Group__0__Impl rule__Layer__Group__1
            {
            pushFollow(FOLLOW_7);
            rule__Layer__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Layer__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Layer__Group__0"


    // $ANTLR start "rule__Layer__Group__0__Impl"
    // InternalNnDsl.g:437:1: rule__Layer__Group__0__Impl : ( ( rule__Layer__NameAssignment_0 ) ) ;
    public final void rule__Layer__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:441:1: ( ( ( rule__Layer__NameAssignment_0 ) ) )
            // InternalNnDsl.g:442:1: ( ( rule__Layer__NameAssignment_0 ) )
            {
            // InternalNnDsl.g:442:1: ( ( rule__Layer__NameAssignment_0 ) )
            // InternalNnDsl.g:443:2: ( rule__Layer__NameAssignment_0 )
            {
             before(grammarAccess.getLayerAccess().getNameAssignment_0()); 
            // InternalNnDsl.g:444:2: ( rule__Layer__NameAssignment_0 )
            // InternalNnDsl.g:444:3: rule__Layer__NameAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Layer__NameAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getLayerAccess().getNameAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Layer__Group__0__Impl"


    // $ANTLR start "rule__Layer__Group__1"
    // InternalNnDsl.g:452:1: rule__Layer__Group__1 : rule__Layer__Group__1__Impl rule__Layer__Group__2 ;
    public final void rule__Layer__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:456:1: ( rule__Layer__Group__1__Impl rule__Layer__Group__2 )
            // InternalNnDsl.g:457:2: rule__Layer__Group__1__Impl rule__Layer__Group__2
            {
            pushFollow(FOLLOW_8);
            rule__Layer__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Layer__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Layer__Group__1"


    // $ANTLR start "rule__Layer__Group__1__Impl"
    // InternalNnDsl.g:464:1: rule__Layer__Group__1__Impl : ( ':' ) ;
    public final void rule__Layer__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:468:1: ( ( ':' ) )
            // InternalNnDsl.g:469:1: ( ':' )
            {
            // InternalNnDsl.g:469:1: ( ':' )
            // InternalNnDsl.g:470:2: ':'
            {
             before(grammarAccess.getLayerAccess().getColonKeyword_1()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getLayerAccess().getColonKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Layer__Group__1__Impl"


    // $ANTLR start "rule__Layer__Group__2"
    // InternalNnDsl.g:479:1: rule__Layer__Group__2 : rule__Layer__Group__2__Impl ;
    public final void rule__Layer__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:483:1: ( rule__Layer__Group__2__Impl )
            // InternalNnDsl.g:484:2: rule__Layer__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Layer__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Layer__Group__2"


    // $ANTLR start "rule__Layer__Group__2__Impl"
    // InternalNnDsl.g:490:1: rule__Layer__Group__2__Impl : ( ( rule__Layer__LiAssignment_2 ) ) ;
    public final void rule__Layer__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:494:1: ( ( ( rule__Layer__LiAssignment_2 ) ) )
            // InternalNnDsl.g:495:1: ( ( rule__Layer__LiAssignment_2 ) )
            {
            // InternalNnDsl.g:495:1: ( ( rule__Layer__LiAssignment_2 ) )
            // InternalNnDsl.g:496:2: ( rule__Layer__LiAssignment_2 )
            {
             before(grammarAccess.getLayerAccess().getLiAssignment_2()); 
            // InternalNnDsl.g:497:2: ( rule__Layer__LiAssignment_2 )
            // InternalNnDsl.g:497:3: rule__Layer__LiAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Layer__LiAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getLayerAccess().getLiAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Layer__Group__2__Impl"


    // $ANTLR start "rule__LayerInfo__Group_0__0"
    // InternalNnDsl.g:506:1: rule__LayerInfo__Group_0__0 : rule__LayerInfo__Group_0__0__Impl rule__LayerInfo__Group_0__1 ;
    public final void rule__LayerInfo__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:510:1: ( rule__LayerInfo__Group_0__0__Impl rule__LayerInfo__Group_0__1 )
            // InternalNnDsl.g:511:2: rule__LayerInfo__Group_0__0__Impl rule__LayerInfo__Group_0__1
            {
            pushFollow(FOLLOW_9);
            rule__LayerInfo__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LayerInfo__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LayerInfo__Group_0__0"


    // $ANTLR start "rule__LayerInfo__Group_0__0__Impl"
    // InternalNnDsl.g:518:1: rule__LayerInfo__Group_0__0__Impl : ( 'Conv' ) ;
    public final void rule__LayerInfo__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:522:1: ( ( 'Conv' ) )
            // InternalNnDsl.g:523:1: ( 'Conv' )
            {
            // InternalNnDsl.g:523:1: ( 'Conv' )
            // InternalNnDsl.g:524:2: 'Conv'
            {
             before(grammarAccess.getLayerInfoAccess().getConvKeyword_0_0()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getLayerInfoAccess().getConvKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LayerInfo__Group_0__0__Impl"


    // $ANTLR start "rule__LayerInfo__Group_0__1"
    // InternalNnDsl.g:533:1: rule__LayerInfo__Group_0__1 : rule__LayerInfo__Group_0__1__Impl ;
    public final void rule__LayerInfo__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:537:1: ( rule__LayerInfo__Group_0__1__Impl )
            // InternalNnDsl.g:538:2: rule__LayerInfo__Group_0__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__LayerInfo__Group_0__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LayerInfo__Group_0__1"


    // $ANTLR start "rule__LayerInfo__Group_0__1__Impl"
    // InternalNnDsl.g:544:1: rule__LayerInfo__Group_0__1__Impl : ( ( rule__LayerInfo__OptionsAssignment_0_1 ) ) ;
    public final void rule__LayerInfo__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:548:1: ( ( ( rule__LayerInfo__OptionsAssignment_0_1 ) ) )
            // InternalNnDsl.g:549:1: ( ( rule__LayerInfo__OptionsAssignment_0_1 ) )
            {
            // InternalNnDsl.g:549:1: ( ( rule__LayerInfo__OptionsAssignment_0_1 ) )
            // InternalNnDsl.g:550:2: ( rule__LayerInfo__OptionsAssignment_0_1 )
            {
             before(grammarAccess.getLayerInfoAccess().getOptionsAssignment_0_1()); 
            // InternalNnDsl.g:551:2: ( rule__LayerInfo__OptionsAssignment_0_1 )
            // InternalNnDsl.g:551:3: rule__LayerInfo__OptionsAssignment_0_1
            {
            pushFollow(FOLLOW_2);
            rule__LayerInfo__OptionsAssignment_0_1();

            state._fsp--;


            }

             after(grammarAccess.getLayerInfoAccess().getOptionsAssignment_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LayerInfo__Group_0__1__Impl"


    // $ANTLR start "rule__LayerInfo__Group_1__0"
    // InternalNnDsl.g:560:1: rule__LayerInfo__Group_1__0 : rule__LayerInfo__Group_1__0__Impl rule__LayerInfo__Group_1__1 ;
    public final void rule__LayerInfo__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:564:1: ( rule__LayerInfo__Group_1__0__Impl rule__LayerInfo__Group_1__1 )
            // InternalNnDsl.g:565:2: rule__LayerInfo__Group_1__0__Impl rule__LayerInfo__Group_1__1
            {
            pushFollow(FOLLOW_9);
            rule__LayerInfo__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LayerInfo__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LayerInfo__Group_1__0"


    // $ANTLR start "rule__LayerInfo__Group_1__0__Impl"
    // InternalNnDsl.g:572:1: rule__LayerInfo__Group_1__0__Impl : ( 'LSTM' ) ;
    public final void rule__LayerInfo__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:576:1: ( ( 'LSTM' ) )
            // InternalNnDsl.g:577:1: ( 'LSTM' )
            {
            // InternalNnDsl.g:577:1: ( 'LSTM' )
            // InternalNnDsl.g:578:2: 'LSTM'
            {
             before(grammarAccess.getLayerInfoAccess().getLSTMKeyword_1_0()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getLayerInfoAccess().getLSTMKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LayerInfo__Group_1__0__Impl"


    // $ANTLR start "rule__LayerInfo__Group_1__1"
    // InternalNnDsl.g:587:1: rule__LayerInfo__Group_1__1 : rule__LayerInfo__Group_1__1__Impl ;
    public final void rule__LayerInfo__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:591:1: ( rule__LayerInfo__Group_1__1__Impl )
            // InternalNnDsl.g:592:2: rule__LayerInfo__Group_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__LayerInfo__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LayerInfo__Group_1__1"


    // $ANTLR start "rule__LayerInfo__Group_1__1__Impl"
    // InternalNnDsl.g:598:1: rule__LayerInfo__Group_1__1__Impl : ( ( rule__LayerInfo__OptionsAssignment_1_1 ) ) ;
    public final void rule__LayerInfo__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:602:1: ( ( ( rule__LayerInfo__OptionsAssignment_1_1 ) ) )
            // InternalNnDsl.g:603:1: ( ( rule__LayerInfo__OptionsAssignment_1_1 ) )
            {
            // InternalNnDsl.g:603:1: ( ( rule__LayerInfo__OptionsAssignment_1_1 ) )
            // InternalNnDsl.g:604:2: ( rule__LayerInfo__OptionsAssignment_1_1 )
            {
             before(grammarAccess.getLayerInfoAccess().getOptionsAssignment_1_1()); 
            // InternalNnDsl.g:605:2: ( rule__LayerInfo__OptionsAssignment_1_1 )
            // InternalNnDsl.g:605:3: rule__LayerInfo__OptionsAssignment_1_1
            {
            pushFollow(FOLLOW_2);
            rule__LayerInfo__OptionsAssignment_1_1();

            state._fsp--;


            }

             after(grammarAccess.getLayerInfoAccess().getOptionsAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LayerInfo__Group_1__1__Impl"


    // $ANTLR start "rule__COptions__Group__0"
    // InternalNnDsl.g:614:1: rule__COptions__Group__0 : rule__COptions__Group__0__Impl rule__COptions__Group__1 ;
    public final void rule__COptions__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:618:1: ( rule__COptions__Group__0__Impl rule__COptions__Group__1 )
            // InternalNnDsl.g:619:2: rule__COptions__Group__0__Impl rule__COptions__Group__1
            {
            pushFollow(FOLLOW_10);
            rule__COptions__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__COptions__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COptions__Group__0"


    // $ANTLR start "rule__COptions__Group__0__Impl"
    // InternalNnDsl.g:626:1: rule__COptions__Group__0__Impl : ( '(' ) ;
    public final void rule__COptions__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:630:1: ( ( '(' ) )
            // InternalNnDsl.g:631:1: ( '(' )
            {
            // InternalNnDsl.g:631:1: ( '(' )
            // InternalNnDsl.g:632:2: '('
            {
             before(grammarAccess.getCOptionsAccess().getLeftParenthesisKeyword_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getCOptionsAccess().getLeftParenthesisKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COptions__Group__0__Impl"


    // $ANTLR start "rule__COptions__Group__1"
    // InternalNnDsl.g:641:1: rule__COptions__Group__1 : rule__COptions__Group__1__Impl rule__COptions__Group__2 ;
    public final void rule__COptions__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:645:1: ( rule__COptions__Group__1__Impl rule__COptions__Group__2 )
            // InternalNnDsl.g:646:2: rule__COptions__Group__1__Impl rule__COptions__Group__2
            {
            pushFollow(FOLLOW_10);
            rule__COptions__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__COptions__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COptions__Group__1"


    // $ANTLR start "rule__COptions__Group__1__Impl"
    // InternalNnDsl.g:653:1: rule__COptions__Group__1__Impl : ( ( rule__COptions__OptionAssignment_1 )? ) ;
    public final void rule__COptions__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:657:1: ( ( ( rule__COptions__OptionAssignment_1 )? ) )
            // InternalNnDsl.g:658:1: ( ( rule__COptions__OptionAssignment_1 )? )
            {
            // InternalNnDsl.g:658:1: ( ( rule__COptions__OptionAssignment_1 )? )
            // InternalNnDsl.g:659:2: ( rule__COptions__OptionAssignment_1 )?
            {
             before(grammarAccess.getCOptionsAccess().getOptionAssignment_1()); 
            // InternalNnDsl.g:660:2: ( rule__COptions__OptionAssignment_1 )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==22||LA5_0==24) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalNnDsl.g:660:3: rule__COptions__OptionAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__COptions__OptionAssignment_1();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getCOptionsAccess().getOptionAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COptions__Group__1__Impl"


    // $ANTLR start "rule__COptions__Group__2"
    // InternalNnDsl.g:668:1: rule__COptions__Group__2 : rule__COptions__Group__2__Impl rule__COptions__Group__3 ;
    public final void rule__COptions__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:672:1: ( rule__COptions__Group__2__Impl rule__COptions__Group__3 )
            // InternalNnDsl.g:673:2: rule__COptions__Group__2__Impl rule__COptions__Group__3
            {
            pushFollow(FOLLOW_10);
            rule__COptions__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__COptions__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COptions__Group__2"


    // $ANTLR start "rule__COptions__Group__2__Impl"
    // InternalNnDsl.g:680:1: rule__COptions__Group__2__Impl : ( ( rule__COptions__Group_2__0 )* ) ;
    public final void rule__COptions__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:684:1: ( ( ( rule__COptions__Group_2__0 )* ) )
            // InternalNnDsl.g:685:1: ( ( rule__COptions__Group_2__0 )* )
            {
            // InternalNnDsl.g:685:1: ( ( rule__COptions__Group_2__0 )* )
            // InternalNnDsl.g:686:2: ( rule__COptions__Group_2__0 )*
            {
             before(grammarAccess.getCOptionsAccess().getGroup_2()); 
            // InternalNnDsl.g:687:2: ( rule__COptions__Group_2__0 )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==21) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalNnDsl.g:687:3: rule__COptions__Group_2__0
            	    {
            	    pushFollow(FOLLOW_11);
            	    rule__COptions__Group_2__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

             after(grammarAccess.getCOptionsAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COptions__Group__2__Impl"


    // $ANTLR start "rule__COptions__Group__3"
    // InternalNnDsl.g:695:1: rule__COptions__Group__3 : rule__COptions__Group__3__Impl ;
    public final void rule__COptions__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:699:1: ( rule__COptions__Group__3__Impl )
            // InternalNnDsl.g:700:2: rule__COptions__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__COptions__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COptions__Group__3"


    // $ANTLR start "rule__COptions__Group__3__Impl"
    // InternalNnDsl.g:706:1: rule__COptions__Group__3__Impl : ( ')' ) ;
    public final void rule__COptions__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:710:1: ( ( ')' ) )
            // InternalNnDsl.g:711:1: ( ')' )
            {
            // InternalNnDsl.g:711:1: ( ')' )
            // InternalNnDsl.g:712:2: ')'
            {
             before(grammarAccess.getCOptionsAccess().getRightParenthesisKeyword_3()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getCOptionsAccess().getRightParenthesisKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COptions__Group__3__Impl"


    // $ANTLR start "rule__COptions__Group_2__0"
    // InternalNnDsl.g:722:1: rule__COptions__Group_2__0 : rule__COptions__Group_2__0__Impl rule__COptions__Group_2__1 ;
    public final void rule__COptions__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:726:1: ( rule__COptions__Group_2__0__Impl rule__COptions__Group_2__1 )
            // InternalNnDsl.g:727:2: rule__COptions__Group_2__0__Impl rule__COptions__Group_2__1
            {
            pushFollow(FOLLOW_12);
            rule__COptions__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__COptions__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COptions__Group_2__0"


    // $ANTLR start "rule__COptions__Group_2__0__Impl"
    // InternalNnDsl.g:734:1: rule__COptions__Group_2__0__Impl : ( ',' ) ;
    public final void rule__COptions__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:738:1: ( ( ',' ) )
            // InternalNnDsl.g:739:1: ( ',' )
            {
            // InternalNnDsl.g:739:1: ( ',' )
            // InternalNnDsl.g:740:2: ','
            {
             before(grammarAccess.getCOptionsAccess().getCommaKeyword_2_0()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getCOptionsAccess().getCommaKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COptions__Group_2__0__Impl"


    // $ANTLR start "rule__COptions__Group_2__1"
    // InternalNnDsl.g:749:1: rule__COptions__Group_2__1 : rule__COptions__Group_2__1__Impl ;
    public final void rule__COptions__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:753:1: ( rule__COptions__Group_2__1__Impl )
            // InternalNnDsl.g:754:2: rule__COptions__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__COptions__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COptions__Group_2__1"


    // $ANTLR start "rule__COptions__Group_2__1__Impl"
    // InternalNnDsl.g:760:1: rule__COptions__Group_2__1__Impl : ( ( rule__COptions__OptionAssignment_2_1 ) ) ;
    public final void rule__COptions__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:764:1: ( ( ( rule__COptions__OptionAssignment_2_1 ) ) )
            // InternalNnDsl.g:765:1: ( ( rule__COptions__OptionAssignment_2_1 ) )
            {
            // InternalNnDsl.g:765:1: ( ( rule__COptions__OptionAssignment_2_1 ) )
            // InternalNnDsl.g:766:2: ( rule__COptions__OptionAssignment_2_1 )
            {
             before(grammarAccess.getCOptionsAccess().getOptionAssignment_2_1()); 
            // InternalNnDsl.g:767:2: ( rule__COptions__OptionAssignment_2_1 )
            // InternalNnDsl.g:767:3: rule__COptions__OptionAssignment_2_1
            {
            pushFollow(FOLLOW_2);
            rule__COptions__OptionAssignment_2_1();

            state._fsp--;


            }

             after(grammarAccess.getCOptionsAccess().getOptionAssignment_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COptions__Group_2__1__Impl"


    // $ANTLR start "rule__COption__Group_0__0"
    // InternalNnDsl.g:776:1: rule__COption__Group_0__0 : rule__COption__Group_0__0__Impl rule__COption__Group_0__1 ;
    public final void rule__COption__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:780:1: ( rule__COption__Group_0__0__Impl rule__COption__Group_0__1 )
            // InternalNnDsl.g:781:2: rule__COption__Group_0__0__Impl rule__COption__Group_0__1
            {
            pushFollow(FOLLOW_13);
            rule__COption__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__COption__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COption__Group_0__0"


    // $ANTLR start "rule__COption__Group_0__0__Impl"
    // InternalNnDsl.g:788:1: rule__COption__Group_0__0__Impl : ( 'kernel_size' ) ;
    public final void rule__COption__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:792:1: ( ( 'kernel_size' ) )
            // InternalNnDsl.g:793:1: ( 'kernel_size' )
            {
            // InternalNnDsl.g:793:1: ( 'kernel_size' )
            // InternalNnDsl.g:794:2: 'kernel_size'
            {
             before(grammarAccess.getCOptionAccess().getKernel_sizeKeyword_0_0()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getCOptionAccess().getKernel_sizeKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COption__Group_0__0__Impl"


    // $ANTLR start "rule__COption__Group_0__1"
    // InternalNnDsl.g:803:1: rule__COption__Group_0__1 : rule__COption__Group_0__1__Impl rule__COption__Group_0__2 ;
    public final void rule__COption__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:807:1: ( rule__COption__Group_0__1__Impl rule__COption__Group_0__2 )
            // InternalNnDsl.g:808:2: rule__COption__Group_0__1__Impl rule__COption__Group_0__2
            {
            pushFollow(FOLLOW_14);
            rule__COption__Group_0__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__COption__Group_0__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COption__Group_0__1"


    // $ANTLR start "rule__COption__Group_0__1__Impl"
    // InternalNnDsl.g:815:1: rule__COption__Group_0__1__Impl : ( '=' ) ;
    public final void rule__COption__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:819:1: ( ( '=' ) )
            // InternalNnDsl.g:820:1: ( '=' )
            {
            // InternalNnDsl.g:820:1: ( '=' )
            // InternalNnDsl.g:821:2: '='
            {
             before(grammarAccess.getCOptionAccess().getEqualsSignKeyword_0_1()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getCOptionAccess().getEqualsSignKeyword_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COption__Group_0__1__Impl"


    // $ANTLR start "rule__COption__Group_0__2"
    // InternalNnDsl.g:830:1: rule__COption__Group_0__2 : rule__COption__Group_0__2__Impl ;
    public final void rule__COption__Group_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:834:1: ( rule__COption__Group_0__2__Impl )
            // InternalNnDsl.g:835:2: rule__COption__Group_0__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__COption__Group_0__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COption__Group_0__2"


    // $ANTLR start "rule__COption__Group_0__2__Impl"
    // InternalNnDsl.g:841:1: rule__COption__Group_0__2__Impl : ( ( rule__COption__KsizeAssignment_0_2 ) ) ;
    public final void rule__COption__Group_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:845:1: ( ( ( rule__COption__KsizeAssignment_0_2 ) ) )
            // InternalNnDsl.g:846:1: ( ( rule__COption__KsizeAssignment_0_2 ) )
            {
            // InternalNnDsl.g:846:1: ( ( rule__COption__KsizeAssignment_0_2 ) )
            // InternalNnDsl.g:847:2: ( rule__COption__KsizeAssignment_0_2 )
            {
             before(grammarAccess.getCOptionAccess().getKsizeAssignment_0_2()); 
            // InternalNnDsl.g:848:2: ( rule__COption__KsizeAssignment_0_2 )
            // InternalNnDsl.g:848:3: rule__COption__KsizeAssignment_0_2
            {
            pushFollow(FOLLOW_2);
            rule__COption__KsizeAssignment_0_2();

            state._fsp--;


            }

             after(grammarAccess.getCOptionAccess().getKsizeAssignment_0_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COption__Group_0__2__Impl"


    // $ANTLR start "rule__COption__Group_1__0"
    // InternalNnDsl.g:857:1: rule__COption__Group_1__0 : rule__COption__Group_1__0__Impl rule__COption__Group_1__1 ;
    public final void rule__COption__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:861:1: ( rule__COption__Group_1__0__Impl rule__COption__Group_1__1 )
            // InternalNnDsl.g:862:2: rule__COption__Group_1__0__Impl rule__COption__Group_1__1
            {
            pushFollow(FOLLOW_13);
            rule__COption__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__COption__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COption__Group_1__0"


    // $ANTLR start "rule__COption__Group_1__0__Impl"
    // InternalNnDsl.g:869:1: rule__COption__Group_1__0__Impl : ( 'filters' ) ;
    public final void rule__COption__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:873:1: ( ( 'filters' ) )
            // InternalNnDsl.g:874:1: ( 'filters' )
            {
            // InternalNnDsl.g:874:1: ( 'filters' )
            // InternalNnDsl.g:875:2: 'filters'
            {
             before(grammarAccess.getCOptionAccess().getFiltersKeyword_1_0()); 
            match(input,24,FOLLOW_2); 
             after(grammarAccess.getCOptionAccess().getFiltersKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COption__Group_1__0__Impl"


    // $ANTLR start "rule__COption__Group_1__1"
    // InternalNnDsl.g:884:1: rule__COption__Group_1__1 : rule__COption__Group_1__1__Impl rule__COption__Group_1__2 ;
    public final void rule__COption__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:888:1: ( rule__COption__Group_1__1__Impl rule__COption__Group_1__2 )
            // InternalNnDsl.g:889:2: rule__COption__Group_1__1__Impl rule__COption__Group_1__2
            {
            pushFollow(FOLLOW_14);
            rule__COption__Group_1__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__COption__Group_1__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COption__Group_1__1"


    // $ANTLR start "rule__COption__Group_1__1__Impl"
    // InternalNnDsl.g:896:1: rule__COption__Group_1__1__Impl : ( '=' ) ;
    public final void rule__COption__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:900:1: ( ( '=' ) )
            // InternalNnDsl.g:901:1: ( '=' )
            {
            // InternalNnDsl.g:901:1: ( '=' )
            // InternalNnDsl.g:902:2: '='
            {
             before(grammarAccess.getCOptionAccess().getEqualsSignKeyword_1_1()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getCOptionAccess().getEqualsSignKeyword_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COption__Group_1__1__Impl"


    // $ANTLR start "rule__COption__Group_1__2"
    // InternalNnDsl.g:911:1: rule__COption__Group_1__2 : rule__COption__Group_1__2__Impl ;
    public final void rule__COption__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:915:1: ( rule__COption__Group_1__2__Impl )
            // InternalNnDsl.g:916:2: rule__COption__Group_1__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__COption__Group_1__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COption__Group_1__2"


    // $ANTLR start "rule__COption__Group_1__2__Impl"
    // InternalNnDsl.g:922:1: rule__COption__Group_1__2__Impl : ( ( rule__COption__FiltersAssignment_1_2 ) ) ;
    public final void rule__COption__Group_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:926:1: ( ( ( rule__COption__FiltersAssignment_1_2 ) ) )
            // InternalNnDsl.g:927:1: ( ( rule__COption__FiltersAssignment_1_2 ) )
            {
            // InternalNnDsl.g:927:1: ( ( rule__COption__FiltersAssignment_1_2 ) )
            // InternalNnDsl.g:928:2: ( rule__COption__FiltersAssignment_1_2 )
            {
             before(grammarAccess.getCOptionAccess().getFiltersAssignment_1_2()); 
            // InternalNnDsl.g:929:2: ( rule__COption__FiltersAssignment_1_2 )
            // InternalNnDsl.g:929:3: rule__COption__FiltersAssignment_1_2
            {
            pushFollow(FOLLOW_2);
            rule__COption__FiltersAssignment_1_2();

            state._fsp--;


            }

             after(grammarAccess.getCOptionAccess().getFiltersAssignment_1_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COption__Group_1__2__Impl"


    // $ANTLR start "rule__LOptions__Group__0"
    // InternalNnDsl.g:938:1: rule__LOptions__Group__0 : rule__LOptions__Group__0__Impl rule__LOptions__Group__1 ;
    public final void rule__LOptions__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:942:1: ( rule__LOptions__Group__0__Impl rule__LOptions__Group__1 )
            // InternalNnDsl.g:943:2: rule__LOptions__Group__0__Impl rule__LOptions__Group__1
            {
            pushFollow(FOLLOW_15);
            rule__LOptions__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LOptions__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOptions__Group__0"


    // $ANTLR start "rule__LOptions__Group__0__Impl"
    // InternalNnDsl.g:950:1: rule__LOptions__Group__0__Impl : ( '(' ) ;
    public final void rule__LOptions__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:954:1: ( ( '(' ) )
            // InternalNnDsl.g:955:1: ( '(' )
            {
            // InternalNnDsl.g:955:1: ( '(' )
            // InternalNnDsl.g:956:2: '('
            {
             before(grammarAccess.getLOptionsAccess().getLeftParenthesisKeyword_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getLOptionsAccess().getLeftParenthesisKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOptions__Group__0__Impl"


    // $ANTLR start "rule__LOptions__Group__1"
    // InternalNnDsl.g:965:1: rule__LOptions__Group__1 : rule__LOptions__Group__1__Impl rule__LOptions__Group__2 ;
    public final void rule__LOptions__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:969:1: ( rule__LOptions__Group__1__Impl rule__LOptions__Group__2 )
            // InternalNnDsl.g:970:2: rule__LOptions__Group__1__Impl rule__LOptions__Group__2
            {
            pushFollow(FOLLOW_15);
            rule__LOptions__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LOptions__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOptions__Group__1"


    // $ANTLR start "rule__LOptions__Group__1__Impl"
    // InternalNnDsl.g:977:1: rule__LOptions__Group__1__Impl : ( ( rule__LOptions__OptionAssignment_1 )? ) ;
    public final void rule__LOptions__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:981:1: ( ( ( rule__LOptions__OptionAssignment_1 )? ) )
            // InternalNnDsl.g:982:1: ( ( rule__LOptions__OptionAssignment_1 )? )
            {
            // InternalNnDsl.g:982:1: ( ( rule__LOptions__OptionAssignment_1 )? )
            // InternalNnDsl.g:983:2: ( rule__LOptions__OptionAssignment_1 )?
            {
             before(grammarAccess.getLOptionsAccess().getOptionAssignment_1()); 
            // InternalNnDsl.g:984:2: ( rule__LOptions__OptionAssignment_1 )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( ((LA7_0>=25 && LA7_0<=26)) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalNnDsl.g:984:3: rule__LOptions__OptionAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__LOptions__OptionAssignment_1();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getLOptionsAccess().getOptionAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOptions__Group__1__Impl"


    // $ANTLR start "rule__LOptions__Group__2"
    // InternalNnDsl.g:992:1: rule__LOptions__Group__2 : rule__LOptions__Group__2__Impl rule__LOptions__Group__3 ;
    public final void rule__LOptions__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:996:1: ( rule__LOptions__Group__2__Impl rule__LOptions__Group__3 )
            // InternalNnDsl.g:997:2: rule__LOptions__Group__2__Impl rule__LOptions__Group__3
            {
            pushFollow(FOLLOW_15);
            rule__LOptions__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LOptions__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOptions__Group__2"


    // $ANTLR start "rule__LOptions__Group__2__Impl"
    // InternalNnDsl.g:1004:1: rule__LOptions__Group__2__Impl : ( ( rule__LOptions__Group_2__0 )* ) ;
    public final void rule__LOptions__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1008:1: ( ( ( rule__LOptions__Group_2__0 )* ) )
            // InternalNnDsl.g:1009:1: ( ( rule__LOptions__Group_2__0 )* )
            {
            // InternalNnDsl.g:1009:1: ( ( rule__LOptions__Group_2__0 )* )
            // InternalNnDsl.g:1010:2: ( rule__LOptions__Group_2__0 )*
            {
             before(grammarAccess.getLOptionsAccess().getGroup_2()); 
            // InternalNnDsl.g:1011:2: ( rule__LOptions__Group_2__0 )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==21) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // InternalNnDsl.g:1011:3: rule__LOptions__Group_2__0
            	    {
            	    pushFollow(FOLLOW_11);
            	    rule__LOptions__Group_2__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

             after(grammarAccess.getLOptionsAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOptions__Group__2__Impl"


    // $ANTLR start "rule__LOptions__Group__3"
    // InternalNnDsl.g:1019:1: rule__LOptions__Group__3 : rule__LOptions__Group__3__Impl ;
    public final void rule__LOptions__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1023:1: ( rule__LOptions__Group__3__Impl )
            // InternalNnDsl.g:1024:2: rule__LOptions__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__LOptions__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOptions__Group__3"


    // $ANTLR start "rule__LOptions__Group__3__Impl"
    // InternalNnDsl.g:1030:1: rule__LOptions__Group__3__Impl : ( ')' ) ;
    public final void rule__LOptions__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1034:1: ( ( ')' ) )
            // InternalNnDsl.g:1035:1: ( ')' )
            {
            // InternalNnDsl.g:1035:1: ( ')' )
            // InternalNnDsl.g:1036:2: ')'
            {
             before(grammarAccess.getLOptionsAccess().getRightParenthesisKeyword_3()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getLOptionsAccess().getRightParenthesisKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOptions__Group__3__Impl"


    // $ANTLR start "rule__LOptions__Group_2__0"
    // InternalNnDsl.g:1046:1: rule__LOptions__Group_2__0 : rule__LOptions__Group_2__0__Impl rule__LOptions__Group_2__1 ;
    public final void rule__LOptions__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1050:1: ( rule__LOptions__Group_2__0__Impl rule__LOptions__Group_2__1 )
            // InternalNnDsl.g:1051:2: rule__LOptions__Group_2__0__Impl rule__LOptions__Group_2__1
            {
            pushFollow(FOLLOW_16);
            rule__LOptions__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LOptions__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOptions__Group_2__0"


    // $ANTLR start "rule__LOptions__Group_2__0__Impl"
    // InternalNnDsl.g:1058:1: rule__LOptions__Group_2__0__Impl : ( ',' ) ;
    public final void rule__LOptions__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1062:1: ( ( ',' ) )
            // InternalNnDsl.g:1063:1: ( ',' )
            {
            // InternalNnDsl.g:1063:1: ( ',' )
            // InternalNnDsl.g:1064:2: ','
            {
             before(grammarAccess.getLOptionsAccess().getCommaKeyword_2_0()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getLOptionsAccess().getCommaKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOptions__Group_2__0__Impl"


    // $ANTLR start "rule__LOptions__Group_2__1"
    // InternalNnDsl.g:1073:1: rule__LOptions__Group_2__1 : rule__LOptions__Group_2__1__Impl ;
    public final void rule__LOptions__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1077:1: ( rule__LOptions__Group_2__1__Impl )
            // InternalNnDsl.g:1078:2: rule__LOptions__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__LOptions__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOptions__Group_2__1"


    // $ANTLR start "rule__LOptions__Group_2__1__Impl"
    // InternalNnDsl.g:1084:1: rule__LOptions__Group_2__1__Impl : ( ( rule__LOptions__OptionAssignment_2_1 ) ) ;
    public final void rule__LOptions__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1088:1: ( ( ( rule__LOptions__OptionAssignment_2_1 ) ) )
            // InternalNnDsl.g:1089:1: ( ( rule__LOptions__OptionAssignment_2_1 ) )
            {
            // InternalNnDsl.g:1089:1: ( ( rule__LOptions__OptionAssignment_2_1 ) )
            // InternalNnDsl.g:1090:2: ( rule__LOptions__OptionAssignment_2_1 )
            {
             before(grammarAccess.getLOptionsAccess().getOptionAssignment_2_1()); 
            // InternalNnDsl.g:1091:2: ( rule__LOptions__OptionAssignment_2_1 )
            // InternalNnDsl.g:1091:3: rule__LOptions__OptionAssignment_2_1
            {
            pushFollow(FOLLOW_2);
            rule__LOptions__OptionAssignment_2_1();

            state._fsp--;


            }

             after(grammarAccess.getLOptionsAccess().getOptionAssignment_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOptions__Group_2__1__Impl"


    // $ANTLR start "rule__LOption__Group_0__0"
    // InternalNnDsl.g:1100:1: rule__LOption__Group_0__0 : rule__LOption__Group_0__0__Impl rule__LOption__Group_0__1 ;
    public final void rule__LOption__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1104:1: ( rule__LOption__Group_0__0__Impl rule__LOption__Group_0__1 )
            // InternalNnDsl.g:1105:2: rule__LOption__Group_0__0__Impl rule__LOption__Group_0__1
            {
            pushFollow(FOLLOW_13);
            rule__LOption__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LOption__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOption__Group_0__0"


    // $ANTLR start "rule__LOption__Group_0__0__Impl"
    // InternalNnDsl.g:1112:1: rule__LOption__Group_0__0__Impl : ( 'activation' ) ;
    public final void rule__LOption__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1116:1: ( ( 'activation' ) )
            // InternalNnDsl.g:1117:1: ( 'activation' )
            {
            // InternalNnDsl.g:1117:1: ( 'activation' )
            // InternalNnDsl.g:1118:2: 'activation'
            {
             before(grammarAccess.getLOptionAccess().getActivationKeyword_0_0()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getLOptionAccess().getActivationKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOption__Group_0__0__Impl"


    // $ANTLR start "rule__LOption__Group_0__1"
    // InternalNnDsl.g:1127:1: rule__LOption__Group_0__1 : rule__LOption__Group_0__1__Impl rule__LOption__Group_0__2 ;
    public final void rule__LOption__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1131:1: ( rule__LOption__Group_0__1__Impl rule__LOption__Group_0__2 )
            // InternalNnDsl.g:1132:2: rule__LOption__Group_0__1__Impl rule__LOption__Group_0__2
            {
            pushFollow(FOLLOW_17);
            rule__LOption__Group_0__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LOption__Group_0__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOption__Group_0__1"


    // $ANTLR start "rule__LOption__Group_0__1__Impl"
    // InternalNnDsl.g:1139:1: rule__LOption__Group_0__1__Impl : ( '=' ) ;
    public final void rule__LOption__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1143:1: ( ( '=' ) )
            // InternalNnDsl.g:1144:1: ( '=' )
            {
            // InternalNnDsl.g:1144:1: ( '=' )
            // InternalNnDsl.g:1145:2: '='
            {
             before(grammarAccess.getLOptionAccess().getEqualsSignKeyword_0_1()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getLOptionAccess().getEqualsSignKeyword_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOption__Group_0__1__Impl"


    // $ANTLR start "rule__LOption__Group_0__2"
    // InternalNnDsl.g:1154:1: rule__LOption__Group_0__2 : rule__LOption__Group_0__2__Impl ;
    public final void rule__LOption__Group_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1158:1: ( rule__LOption__Group_0__2__Impl )
            // InternalNnDsl.g:1159:2: rule__LOption__Group_0__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__LOption__Group_0__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOption__Group_0__2"


    // $ANTLR start "rule__LOption__Group_0__2__Impl"
    // InternalNnDsl.g:1165:1: rule__LOption__Group_0__2__Impl : ( ( rule__LOption__ActFctAssignment_0_2 ) ) ;
    public final void rule__LOption__Group_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1169:1: ( ( ( rule__LOption__ActFctAssignment_0_2 ) ) )
            // InternalNnDsl.g:1170:1: ( ( rule__LOption__ActFctAssignment_0_2 ) )
            {
            // InternalNnDsl.g:1170:1: ( ( rule__LOption__ActFctAssignment_0_2 ) )
            // InternalNnDsl.g:1171:2: ( rule__LOption__ActFctAssignment_0_2 )
            {
             before(grammarAccess.getLOptionAccess().getActFctAssignment_0_2()); 
            // InternalNnDsl.g:1172:2: ( rule__LOption__ActFctAssignment_0_2 )
            // InternalNnDsl.g:1172:3: rule__LOption__ActFctAssignment_0_2
            {
            pushFollow(FOLLOW_2);
            rule__LOption__ActFctAssignment_0_2();

            state._fsp--;


            }

             after(grammarAccess.getLOptionAccess().getActFctAssignment_0_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOption__Group_0__2__Impl"


    // $ANTLR start "rule__LOption__Group_1__0"
    // InternalNnDsl.g:1181:1: rule__LOption__Group_1__0 : rule__LOption__Group_1__0__Impl rule__LOption__Group_1__1 ;
    public final void rule__LOption__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1185:1: ( rule__LOption__Group_1__0__Impl rule__LOption__Group_1__1 )
            // InternalNnDsl.g:1186:2: rule__LOption__Group_1__0__Impl rule__LOption__Group_1__1
            {
            pushFollow(FOLLOW_13);
            rule__LOption__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LOption__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOption__Group_1__0"


    // $ANTLR start "rule__LOption__Group_1__0__Impl"
    // InternalNnDsl.g:1193:1: rule__LOption__Group_1__0__Impl : ( 'use_bias' ) ;
    public final void rule__LOption__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1197:1: ( ( 'use_bias' ) )
            // InternalNnDsl.g:1198:1: ( 'use_bias' )
            {
            // InternalNnDsl.g:1198:1: ( 'use_bias' )
            // InternalNnDsl.g:1199:2: 'use_bias'
            {
             before(grammarAccess.getLOptionAccess().getUse_biasKeyword_1_0()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getLOptionAccess().getUse_biasKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOption__Group_1__0__Impl"


    // $ANTLR start "rule__LOption__Group_1__1"
    // InternalNnDsl.g:1208:1: rule__LOption__Group_1__1 : rule__LOption__Group_1__1__Impl rule__LOption__Group_1__2 ;
    public final void rule__LOption__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1212:1: ( rule__LOption__Group_1__1__Impl rule__LOption__Group_1__2 )
            // InternalNnDsl.g:1213:2: rule__LOption__Group_1__1__Impl rule__LOption__Group_1__2
            {
            pushFollow(FOLLOW_18);
            rule__LOption__Group_1__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LOption__Group_1__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOption__Group_1__1"


    // $ANTLR start "rule__LOption__Group_1__1__Impl"
    // InternalNnDsl.g:1220:1: rule__LOption__Group_1__1__Impl : ( '=' ) ;
    public final void rule__LOption__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1224:1: ( ( '=' ) )
            // InternalNnDsl.g:1225:1: ( '=' )
            {
            // InternalNnDsl.g:1225:1: ( '=' )
            // InternalNnDsl.g:1226:2: '='
            {
             before(grammarAccess.getLOptionAccess().getEqualsSignKeyword_1_1()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getLOptionAccess().getEqualsSignKeyword_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOption__Group_1__1__Impl"


    // $ANTLR start "rule__LOption__Group_1__2"
    // InternalNnDsl.g:1235:1: rule__LOption__Group_1__2 : rule__LOption__Group_1__2__Impl ;
    public final void rule__LOption__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1239:1: ( rule__LOption__Group_1__2__Impl )
            // InternalNnDsl.g:1240:2: rule__LOption__Group_1__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__LOption__Group_1__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOption__Group_1__2"


    // $ANTLR start "rule__LOption__Group_1__2__Impl"
    // InternalNnDsl.g:1246:1: rule__LOption__Group_1__2__Impl : ( ( rule__LOption__UseBiasAssignment_1_2 ) ) ;
    public final void rule__LOption__Group_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1250:1: ( ( ( rule__LOption__UseBiasAssignment_1_2 ) ) )
            // InternalNnDsl.g:1251:1: ( ( rule__LOption__UseBiasAssignment_1_2 ) )
            {
            // InternalNnDsl.g:1251:1: ( ( rule__LOption__UseBiasAssignment_1_2 ) )
            // InternalNnDsl.g:1252:2: ( rule__LOption__UseBiasAssignment_1_2 )
            {
             before(grammarAccess.getLOptionAccess().getUseBiasAssignment_1_2()); 
            // InternalNnDsl.g:1253:2: ( rule__LOption__UseBiasAssignment_1_2 )
            // InternalNnDsl.g:1253:3: rule__LOption__UseBiasAssignment_1_2
            {
            pushFollow(FOLLOW_2);
            rule__LOption__UseBiasAssignment_1_2();

            state._fsp--;


            }

             after(grammarAccess.getLOptionAccess().getUseBiasAssignment_1_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOption__Group_1__2__Impl"


    // $ANTLR start "rule__Model__NameAssignment_1"
    // InternalNnDsl.g:1262:1: rule__Model__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Model__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1266:1: ( ( RULE_ID ) )
            // InternalNnDsl.g:1267:2: ( RULE_ID )
            {
            // InternalNnDsl.g:1267:2: ( RULE_ID )
            // InternalNnDsl.g:1268:3: RULE_ID
            {
             before(grammarAccess.getModelAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getModelAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__NameAssignment_1"


    // $ANTLR start "rule__Model__LayersAssignment_3"
    // InternalNnDsl.g:1277:1: rule__Model__LayersAssignment_3 : ( ruleLayer ) ;
    public final void rule__Model__LayersAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1281:1: ( ( ruleLayer ) )
            // InternalNnDsl.g:1282:2: ( ruleLayer )
            {
            // InternalNnDsl.g:1282:2: ( ruleLayer )
            // InternalNnDsl.g:1283:3: ruleLayer
            {
             before(grammarAccess.getModelAccess().getLayersLayerParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleLayer();

            state._fsp--;

             after(grammarAccess.getModelAccess().getLayersLayerParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__LayersAssignment_3"


    // $ANTLR start "rule__Layer__NameAssignment_0"
    // InternalNnDsl.g:1292:1: rule__Layer__NameAssignment_0 : ( RULE_ID ) ;
    public final void rule__Layer__NameAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1296:1: ( ( RULE_ID ) )
            // InternalNnDsl.g:1297:2: ( RULE_ID )
            {
            // InternalNnDsl.g:1297:2: ( RULE_ID )
            // InternalNnDsl.g:1298:3: RULE_ID
            {
             before(grammarAccess.getLayerAccess().getNameIDTerminalRuleCall_0_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getLayerAccess().getNameIDTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Layer__NameAssignment_0"


    // $ANTLR start "rule__Layer__LiAssignment_2"
    // InternalNnDsl.g:1307:1: rule__Layer__LiAssignment_2 : ( ruleLayerInfo ) ;
    public final void rule__Layer__LiAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1311:1: ( ( ruleLayerInfo ) )
            // InternalNnDsl.g:1312:2: ( ruleLayerInfo )
            {
            // InternalNnDsl.g:1312:2: ( ruleLayerInfo )
            // InternalNnDsl.g:1313:3: ruleLayerInfo
            {
             before(grammarAccess.getLayerAccess().getLiLayerInfoParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleLayerInfo();

            state._fsp--;

             after(grammarAccess.getLayerAccess().getLiLayerInfoParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Layer__LiAssignment_2"


    // $ANTLR start "rule__LayerInfo__OptionsAssignment_0_1"
    // InternalNnDsl.g:1322:1: rule__LayerInfo__OptionsAssignment_0_1 : ( ruleCOptions ) ;
    public final void rule__LayerInfo__OptionsAssignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1326:1: ( ( ruleCOptions ) )
            // InternalNnDsl.g:1327:2: ( ruleCOptions )
            {
            // InternalNnDsl.g:1327:2: ( ruleCOptions )
            // InternalNnDsl.g:1328:3: ruleCOptions
            {
             before(grammarAccess.getLayerInfoAccess().getOptionsCOptionsParserRuleCall_0_1_0()); 
            pushFollow(FOLLOW_2);
            ruleCOptions();

            state._fsp--;

             after(grammarAccess.getLayerInfoAccess().getOptionsCOptionsParserRuleCall_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LayerInfo__OptionsAssignment_0_1"


    // $ANTLR start "rule__LayerInfo__OptionsAssignment_1_1"
    // InternalNnDsl.g:1337:1: rule__LayerInfo__OptionsAssignment_1_1 : ( ruleLOptions ) ;
    public final void rule__LayerInfo__OptionsAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1341:1: ( ( ruleLOptions ) )
            // InternalNnDsl.g:1342:2: ( ruleLOptions )
            {
            // InternalNnDsl.g:1342:2: ( ruleLOptions )
            // InternalNnDsl.g:1343:3: ruleLOptions
            {
             before(grammarAccess.getLayerInfoAccess().getOptionsLOptionsParserRuleCall_1_1_0()); 
            pushFollow(FOLLOW_2);
            ruleLOptions();

            state._fsp--;

             after(grammarAccess.getLayerInfoAccess().getOptionsLOptionsParserRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LayerInfo__OptionsAssignment_1_1"


    // $ANTLR start "rule__COptions__OptionAssignment_1"
    // InternalNnDsl.g:1352:1: rule__COptions__OptionAssignment_1 : ( ruleCOption ) ;
    public final void rule__COptions__OptionAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1356:1: ( ( ruleCOption ) )
            // InternalNnDsl.g:1357:2: ( ruleCOption )
            {
            // InternalNnDsl.g:1357:2: ( ruleCOption )
            // InternalNnDsl.g:1358:3: ruleCOption
            {
             before(grammarAccess.getCOptionsAccess().getOptionCOptionParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleCOption();

            state._fsp--;

             after(grammarAccess.getCOptionsAccess().getOptionCOptionParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COptions__OptionAssignment_1"


    // $ANTLR start "rule__COptions__OptionAssignment_2_1"
    // InternalNnDsl.g:1367:1: rule__COptions__OptionAssignment_2_1 : ( ruleCOption ) ;
    public final void rule__COptions__OptionAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1371:1: ( ( ruleCOption ) )
            // InternalNnDsl.g:1372:2: ( ruleCOption )
            {
            // InternalNnDsl.g:1372:2: ( ruleCOption )
            // InternalNnDsl.g:1373:3: ruleCOption
            {
             before(grammarAccess.getCOptionsAccess().getOptionCOptionParserRuleCall_2_1_0()); 
            pushFollow(FOLLOW_2);
            ruleCOption();

            state._fsp--;

             after(grammarAccess.getCOptionsAccess().getOptionCOptionParserRuleCall_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COptions__OptionAssignment_2_1"


    // $ANTLR start "rule__COption__KsizeAssignment_0_2"
    // InternalNnDsl.g:1382:1: rule__COption__KsizeAssignment_0_2 : ( RULE_INT ) ;
    public final void rule__COption__KsizeAssignment_0_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1386:1: ( ( RULE_INT ) )
            // InternalNnDsl.g:1387:2: ( RULE_INT )
            {
            // InternalNnDsl.g:1387:2: ( RULE_INT )
            // InternalNnDsl.g:1388:3: RULE_INT
            {
             before(grammarAccess.getCOptionAccess().getKsizeINTTerminalRuleCall_0_2_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getCOptionAccess().getKsizeINTTerminalRuleCall_0_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COption__KsizeAssignment_0_2"


    // $ANTLR start "rule__COption__FiltersAssignment_1_2"
    // InternalNnDsl.g:1397:1: rule__COption__FiltersAssignment_1_2 : ( RULE_INT ) ;
    public final void rule__COption__FiltersAssignment_1_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1401:1: ( ( RULE_INT ) )
            // InternalNnDsl.g:1402:2: ( RULE_INT )
            {
            // InternalNnDsl.g:1402:2: ( RULE_INT )
            // InternalNnDsl.g:1403:3: RULE_INT
            {
             before(grammarAccess.getCOptionAccess().getFiltersINTTerminalRuleCall_1_2_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getCOptionAccess().getFiltersINTTerminalRuleCall_1_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__COption__FiltersAssignment_1_2"


    // $ANTLR start "rule__LOptions__OptionAssignment_1"
    // InternalNnDsl.g:1412:1: rule__LOptions__OptionAssignment_1 : ( ruleLOption ) ;
    public final void rule__LOptions__OptionAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1416:1: ( ( ruleLOption ) )
            // InternalNnDsl.g:1417:2: ( ruleLOption )
            {
            // InternalNnDsl.g:1417:2: ( ruleLOption )
            // InternalNnDsl.g:1418:3: ruleLOption
            {
             before(grammarAccess.getLOptionsAccess().getOptionLOptionParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleLOption();

            state._fsp--;

             after(grammarAccess.getLOptionsAccess().getOptionLOptionParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOptions__OptionAssignment_1"


    // $ANTLR start "rule__LOptions__OptionAssignment_2_1"
    // InternalNnDsl.g:1427:1: rule__LOptions__OptionAssignment_2_1 : ( ruleLOption ) ;
    public final void rule__LOptions__OptionAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1431:1: ( ( ruleLOption ) )
            // InternalNnDsl.g:1432:2: ( ruleLOption )
            {
            // InternalNnDsl.g:1432:2: ( ruleLOption )
            // InternalNnDsl.g:1433:3: ruleLOption
            {
             before(grammarAccess.getLOptionsAccess().getOptionLOptionParserRuleCall_2_1_0()); 
            pushFollow(FOLLOW_2);
            ruleLOption();

            state._fsp--;

             after(grammarAccess.getLOptionsAccess().getOptionLOptionParserRuleCall_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOptions__OptionAssignment_2_1"


    // $ANTLR start "rule__LOption__ActFctAssignment_0_2"
    // InternalNnDsl.g:1442:1: rule__LOption__ActFctAssignment_0_2 : ( RULE_ACTIVATION ) ;
    public final void rule__LOption__ActFctAssignment_0_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1446:1: ( ( RULE_ACTIVATION ) )
            // InternalNnDsl.g:1447:2: ( RULE_ACTIVATION )
            {
            // InternalNnDsl.g:1447:2: ( RULE_ACTIVATION )
            // InternalNnDsl.g:1448:3: RULE_ACTIVATION
            {
             before(grammarAccess.getLOptionAccess().getActFctACTIVATIONTerminalRuleCall_0_2_0()); 
            match(input,RULE_ACTIVATION,FOLLOW_2); 
             after(grammarAccess.getLOptionAccess().getActFctACTIVATIONTerminalRuleCall_0_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOption__ActFctAssignment_0_2"


    // $ANTLR start "rule__LOption__UseBiasAssignment_1_2"
    // InternalNnDsl.g:1457:1: rule__LOption__UseBiasAssignment_1_2 : ( RULE_BOOLEAN ) ;
    public final void rule__LOption__UseBiasAssignment_1_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalNnDsl.g:1461:1: ( ( RULE_BOOLEAN ) )
            // InternalNnDsl.g:1462:2: ( RULE_BOOLEAN )
            {
            // InternalNnDsl.g:1462:2: ( RULE_BOOLEAN )
            // InternalNnDsl.g:1463:3: RULE_BOOLEAN
            {
             before(grammarAccess.getLOptionAccess().getUseBiasBOOLEANTerminalRuleCall_1_2_0()); 
            match(input,RULE_BOOLEAN,FOLLOW_2); 
             after(grammarAccess.getLOptionAccess().getUseBiasBOOLEANTerminalRuleCall_1_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LOption__UseBiasAssignment_1_2"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000008010L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000060000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000001700000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000200002L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000001400000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000006300000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000006000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000000080L});

}