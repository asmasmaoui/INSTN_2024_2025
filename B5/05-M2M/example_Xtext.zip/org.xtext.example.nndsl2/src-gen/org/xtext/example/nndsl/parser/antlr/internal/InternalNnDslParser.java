package org.xtext.example.nndsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.example.nndsl.services.NnDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalNnDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INT", "RULE_ACTIVATION", "RULE_BOOLEAN", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'network'", "'{'", "'}'", "':'", "'Conv'", "'LSTM'", "'('", "','", "')'", "'kernel_size'", "'='", "'filters'", "'activation'", "'use_bias'"
    };
    public static final int RULE_BOOLEAN=7;
    public static final int RULE_STRING=8;
    public static final int RULE_SL_COMMENT=10;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ACTIVATION=6;
    public static final int RULE_ID=4;
    public static final int RULE_WS=11;
    public static final int RULE_ANY_OTHER=12;
    public static final int T__26=26;
    public static final int RULE_INT=5;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=9;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalNnDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalNnDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalNnDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalNnDsl.g"; }



     	private NnDslGrammarAccess grammarAccess;

        public InternalNnDslParser(TokenStream input, NnDslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Model";
       	}

       	@Override
       	protected NnDslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleModel"
    // InternalNnDsl.g:64:1: entryRuleModel returns [EObject current=null] : iv_ruleModel= ruleModel EOF ;
    public final EObject entryRuleModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModel = null;


        try {
            // InternalNnDsl.g:64:46: (iv_ruleModel= ruleModel EOF )
            // InternalNnDsl.g:65:2: iv_ruleModel= ruleModel EOF
            {
             newCompositeNode(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleModel=ruleModel();

            state._fsp--;

             current =iv_ruleModel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalNnDsl.g:71:1: ruleModel returns [EObject current=null] : (otherlv_0= 'network' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_layers_3_0= ruleLayer ) )* otherlv_4= '}' ) ;
    public final EObject ruleModel() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_layers_3_0 = null;



        	enterRule();

        try {
            // InternalNnDsl.g:77:2: ( (otherlv_0= 'network' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_layers_3_0= ruleLayer ) )* otherlv_4= '}' ) )
            // InternalNnDsl.g:78:2: (otherlv_0= 'network' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_layers_3_0= ruleLayer ) )* otherlv_4= '}' )
            {
            // InternalNnDsl.g:78:2: (otherlv_0= 'network' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_layers_3_0= ruleLayer ) )* otherlv_4= '}' )
            // InternalNnDsl.g:79:3: otherlv_0= 'network' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_layers_3_0= ruleLayer ) )* otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,13,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getModelAccess().getNetworkKeyword_0());
            		
            // InternalNnDsl.g:83:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalNnDsl.g:84:4: (lv_name_1_0= RULE_ID )
            {
            // InternalNnDsl.g:84:4: (lv_name_1_0= RULE_ID )
            // InternalNnDsl.g:85:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            					newLeafNode(lv_name_1_0, grammarAccess.getModelAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getModelRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,14,FOLLOW_5); 

            			newLeafNode(otherlv_2, grammarAccess.getModelAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalNnDsl.g:105:3: ( (lv_layers_3_0= ruleLayer ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==RULE_ID) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalNnDsl.g:106:4: (lv_layers_3_0= ruleLayer )
            	    {
            	    // InternalNnDsl.g:106:4: (lv_layers_3_0= ruleLayer )
            	    // InternalNnDsl.g:107:5: lv_layers_3_0= ruleLayer
            	    {

            	    					newCompositeNode(grammarAccess.getModelAccess().getLayersLayerParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_5);
            	    lv_layers_3_0=ruleLayer();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getModelRule());
            	    					}
            	    					add(
            	    						current,
            	    						"layers",
            	    						lv_layers_3_0,
            	    						"org.xtext.example.nndsl.NnDsl.Layer");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

            otherlv_4=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getModelAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleLayer"
    // InternalNnDsl.g:132:1: entryRuleLayer returns [EObject current=null] : iv_ruleLayer= ruleLayer EOF ;
    public final EObject entryRuleLayer() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLayer = null;


        try {
            // InternalNnDsl.g:132:46: (iv_ruleLayer= ruleLayer EOF )
            // InternalNnDsl.g:133:2: iv_ruleLayer= ruleLayer EOF
            {
             newCompositeNode(grammarAccess.getLayerRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLayer=ruleLayer();

            state._fsp--;

             current =iv_ruleLayer; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLayer"


    // $ANTLR start "ruleLayer"
    // InternalNnDsl.g:139:1: ruleLayer returns [EObject current=null] : ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= ':' ( (lv_li_2_0= ruleLayerInfo ) ) ) ;
    public final EObject ruleLayer() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        Token otherlv_1=null;
        EObject lv_li_2_0 = null;



        	enterRule();

        try {
            // InternalNnDsl.g:145:2: ( ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= ':' ( (lv_li_2_0= ruleLayerInfo ) ) ) )
            // InternalNnDsl.g:146:2: ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= ':' ( (lv_li_2_0= ruleLayerInfo ) ) )
            {
            // InternalNnDsl.g:146:2: ( ( (lv_name_0_0= RULE_ID ) ) otherlv_1= ':' ( (lv_li_2_0= ruleLayerInfo ) ) )
            // InternalNnDsl.g:147:3: ( (lv_name_0_0= RULE_ID ) ) otherlv_1= ':' ( (lv_li_2_0= ruleLayerInfo ) )
            {
            // InternalNnDsl.g:147:3: ( (lv_name_0_0= RULE_ID ) )
            // InternalNnDsl.g:148:4: (lv_name_0_0= RULE_ID )
            {
            // InternalNnDsl.g:148:4: (lv_name_0_0= RULE_ID )
            // InternalNnDsl.g:149:5: lv_name_0_0= RULE_ID
            {
            lv_name_0_0=(Token)match(input,RULE_ID,FOLLOW_6); 

            					newLeafNode(lv_name_0_0, grammarAccess.getLayerAccess().getNameIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getLayerRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_1=(Token)match(input,16,FOLLOW_7); 

            			newLeafNode(otherlv_1, grammarAccess.getLayerAccess().getColonKeyword_1());
            		
            // InternalNnDsl.g:169:3: ( (lv_li_2_0= ruleLayerInfo ) )
            // InternalNnDsl.g:170:4: (lv_li_2_0= ruleLayerInfo )
            {
            // InternalNnDsl.g:170:4: (lv_li_2_0= ruleLayerInfo )
            // InternalNnDsl.g:171:5: lv_li_2_0= ruleLayerInfo
            {

            					newCompositeNode(grammarAccess.getLayerAccess().getLiLayerInfoParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_2);
            lv_li_2_0=ruleLayerInfo();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getLayerRule());
            					}
            					set(
            						current,
            						"li",
            						lv_li_2_0,
            						"org.xtext.example.nndsl.NnDsl.LayerInfo");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLayer"


    // $ANTLR start "entryRuleLayerInfo"
    // InternalNnDsl.g:192:1: entryRuleLayerInfo returns [EObject current=null] : iv_ruleLayerInfo= ruleLayerInfo EOF ;
    public final EObject entryRuleLayerInfo() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLayerInfo = null;


        try {
            // InternalNnDsl.g:192:50: (iv_ruleLayerInfo= ruleLayerInfo EOF )
            // InternalNnDsl.g:193:2: iv_ruleLayerInfo= ruleLayerInfo EOF
            {
             newCompositeNode(grammarAccess.getLayerInfoRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLayerInfo=ruleLayerInfo();

            state._fsp--;

             current =iv_ruleLayerInfo; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLayerInfo"


    // $ANTLR start "ruleLayerInfo"
    // InternalNnDsl.g:199:1: ruleLayerInfo returns [EObject current=null] : ( (otherlv_0= 'Conv' ( (lv_options_1_0= ruleCOptions ) ) ) | (otherlv_2= 'LSTM' ( (lv_options_3_0= ruleLOptions ) ) ) ) ;
    public final EObject ruleLayerInfo() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        EObject lv_options_1_0 = null;

        EObject lv_options_3_0 = null;



        	enterRule();

        try {
            // InternalNnDsl.g:205:2: ( ( (otherlv_0= 'Conv' ( (lv_options_1_0= ruleCOptions ) ) ) | (otherlv_2= 'LSTM' ( (lv_options_3_0= ruleLOptions ) ) ) ) )
            // InternalNnDsl.g:206:2: ( (otherlv_0= 'Conv' ( (lv_options_1_0= ruleCOptions ) ) ) | (otherlv_2= 'LSTM' ( (lv_options_3_0= ruleLOptions ) ) ) )
            {
            // InternalNnDsl.g:206:2: ( (otherlv_0= 'Conv' ( (lv_options_1_0= ruleCOptions ) ) ) | (otherlv_2= 'LSTM' ( (lv_options_3_0= ruleLOptions ) ) ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==17) ) {
                alt2=1;
            }
            else if ( (LA2_0==18) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalNnDsl.g:207:3: (otherlv_0= 'Conv' ( (lv_options_1_0= ruleCOptions ) ) )
                    {
                    // InternalNnDsl.g:207:3: (otherlv_0= 'Conv' ( (lv_options_1_0= ruleCOptions ) ) )
                    // InternalNnDsl.g:208:4: otherlv_0= 'Conv' ( (lv_options_1_0= ruleCOptions ) )
                    {
                    otherlv_0=(Token)match(input,17,FOLLOW_8); 

                    				newLeafNode(otherlv_0, grammarAccess.getLayerInfoAccess().getConvKeyword_0_0());
                    			
                    // InternalNnDsl.g:212:4: ( (lv_options_1_0= ruleCOptions ) )
                    // InternalNnDsl.g:213:5: (lv_options_1_0= ruleCOptions )
                    {
                    // InternalNnDsl.g:213:5: (lv_options_1_0= ruleCOptions )
                    // InternalNnDsl.g:214:6: lv_options_1_0= ruleCOptions
                    {

                    						newCompositeNode(grammarAccess.getLayerInfoAccess().getOptionsCOptionsParserRuleCall_0_1_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_options_1_0=ruleCOptions();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getLayerInfoRule());
                    						}
                    						add(
                    							current,
                    							"options",
                    							lv_options_1_0,
                    							"org.xtext.example.nndsl.NnDsl.COptions");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalNnDsl.g:233:3: (otherlv_2= 'LSTM' ( (lv_options_3_0= ruleLOptions ) ) )
                    {
                    // InternalNnDsl.g:233:3: (otherlv_2= 'LSTM' ( (lv_options_3_0= ruleLOptions ) ) )
                    // InternalNnDsl.g:234:4: otherlv_2= 'LSTM' ( (lv_options_3_0= ruleLOptions ) )
                    {
                    otherlv_2=(Token)match(input,18,FOLLOW_8); 

                    				newLeafNode(otherlv_2, grammarAccess.getLayerInfoAccess().getLSTMKeyword_1_0());
                    			
                    // InternalNnDsl.g:238:4: ( (lv_options_3_0= ruleLOptions ) )
                    // InternalNnDsl.g:239:5: (lv_options_3_0= ruleLOptions )
                    {
                    // InternalNnDsl.g:239:5: (lv_options_3_0= ruleLOptions )
                    // InternalNnDsl.g:240:6: lv_options_3_0= ruleLOptions
                    {

                    						newCompositeNode(grammarAccess.getLayerInfoAccess().getOptionsLOptionsParserRuleCall_1_1_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_options_3_0=ruleLOptions();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getLayerInfoRule());
                    						}
                    						add(
                    							current,
                    							"options",
                    							lv_options_3_0,
                    							"org.xtext.example.nndsl.NnDsl.LOptions");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLayerInfo"


    // $ANTLR start "entryRuleCOptions"
    // InternalNnDsl.g:262:1: entryRuleCOptions returns [EObject current=null] : iv_ruleCOptions= ruleCOptions EOF ;
    public final EObject entryRuleCOptions() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCOptions = null;


        try {
            // InternalNnDsl.g:262:49: (iv_ruleCOptions= ruleCOptions EOF )
            // InternalNnDsl.g:263:2: iv_ruleCOptions= ruleCOptions EOF
            {
             newCompositeNode(grammarAccess.getCOptionsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCOptions=ruleCOptions();

            state._fsp--;

             current =iv_ruleCOptions; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCOptions"


    // $ANTLR start "ruleCOptions"
    // InternalNnDsl.g:269:1: ruleCOptions returns [EObject current=null] : (otherlv_0= '(' ( (lv_option_1_0= ruleCOption ) )? (otherlv_2= ',' ( (lv_option_3_0= ruleCOption ) ) )* otherlv_4= ')' ) ;
    public final EObject ruleCOptions() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_option_1_0 = null;

        EObject lv_option_3_0 = null;



        	enterRule();

        try {
            // InternalNnDsl.g:275:2: ( (otherlv_0= '(' ( (lv_option_1_0= ruleCOption ) )? (otherlv_2= ',' ( (lv_option_3_0= ruleCOption ) ) )* otherlv_4= ')' ) )
            // InternalNnDsl.g:276:2: (otherlv_0= '(' ( (lv_option_1_0= ruleCOption ) )? (otherlv_2= ',' ( (lv_option_3_0= ruleCOption ) ) )* otherlv_4= ')' )
            {
            // InternalNnDsl.g:276:2: (otherlv_0= '(' ( (lv_option_1_0= ruleCOption ) )? (otherlv_2= ',' ( (lv_option_3_0= ruleCOption ) ) )* otherlv_4= ')' )
            // InternalNnDsl.g:277:3: otherlv_0= '(' ( (lv_option_1_0= ruleCOption ) )? (otherlv_2= ',' ( (lv_option_3_0= ruleCOption ) ) )* otherlv_4= ')'
            {
            otherlv_0=(Token)match(input,19,FOLLOW_9); 

            			newLeafNode(otherlv_0, grammarAccess.getCOptionsAccess().getLeftParenthesisKeyword_0());
            		
            // InternalNnDsl.g:281:3: ( (lv_option_1_0= ruleCOption ) )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==22||LA3_0==24) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalNnDsl.g:282:4: (lv_option_1_0= ruleCOption )
                    {
                    // InternalNnDsl.g:282:4: (lv_option_1_0= ruleCOption )
                    // InternalNnDsl.g:283:5: lv_option_1_0= ruleCOption
                    {

                    					newCompositeNode(grammarAccess.getCOptionsAccess().getOptionCOptionParserRuleCall_1_0());
                    				
                    pushFollow(FOLLOW_10);
                    lv_option_1_0=ruleCOption();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getCOptionsRule());
                    					}
                    					add(
                    						current,
                    						"option",
                    						lv_option_1_0,
                    						"org.xtext.example.nndsl.NnDsl.COption");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalNnDsl.g:300:3: (otherlv_2= ',' ( (lv_option_3_0= ruleCOption ) ) )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==20) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalNnDsl.g:301:4: otherlv_2= ',' ( (lv_option_3_0= ruleCOption ) )
            	    {
            	    otherlv_2=(Token)match(input,20,FOLLOW_11); 

            	    				newLeafNode(otherlv_2, grammarAccess.getCOptionsAccess().getCommaKeyword_2_0());
            	    			
            	    // InternalNnDsl.g:305:4: ( (lv_option_3_0= ruleCOption ) )
            	    // InternalNnDsl.g:306:5: (lv_option_3_0= ruleCOption )
            	    {
            	    // InternalNnDsl.g:306:5: (lv_option_3_0= ruleCOption )
            	    // InternalNnDsl.g:307:6: lv_option_3_0= ruleCOption
            	    {

            	    						newCompositeNode(grammarAccess.getCOptionsAccess().getOptionCOptionParserRuleCall_2_1_0());
            	    					
            	    pushFollow(FOLLOW_10);
            	    lv_option_3_0=ruleCOption();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getCOptionsRule());
            	    						}
            	    						add(
            	    							current,
            	    							"option",
            	    							lv_option_3_0,
            	    							"org.xtext.example.nndsl.NnDsl.COption");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            otherlv_4=(Token)match(input,21,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getCOptionsAccess().getRightParenthesisKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCOptions"


    // $ANTLR start "entryRuleCOption"
    // InternalNnDsl.g:333:1: entryRuleCOption returns [EObject current=null] : iv_ruleCOption= ruleCOption EOF ;
    public final EObject entryRuleCOption() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCOption = null;


        try {
            // InternalNnDsl.g:333:48: (iv_ruleCOption= ruleCOption EOF )
            // InternalNnDsl.g:334:2: iv_ruleCOption= ruleCOption EOF
            {
             newCompositeNode(grammarAccess.getCOptionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCOption=ruleCOption();

            state._fsp--;

             current =iv_ruleCOption; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCOption"


    // $ANTLR start "ruleCOption"
    // InternalNnDsl.g:340:1: ruleCOption returns [EObject current=null] : ( (otherlv_0= 'kernel_size' otherlv_1= '=' ( (lv_ksize_2_0= RULE_INT ) ) ) | (otherlv_3= 'filters' otherlv_4= '=' ( (lv_filters_5_0= RULE_INT ) ) ) ) ;
    public final EObject ruleCOption() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_ksize_2_0=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token lv_filters_5_0=null;


        	enterRule();

        try {
            // InternalNnDsl.g:346:2: ( ( (otherlv_0= 'kernel_size' otherlv_1= '=' ( (lv_ksize_2_0= RULE_INT ) ) ) | (otherlv_3= 'filters' otherlv_4= '=' ( (lv_filters_5_0= RULE_INT ) ) ) ) )
            // InternalNnDsl.g:347:2: ( (otherlv_0= 'kernel_size' otherlv_1= '=' ( (lv_ksize_2_0= RULE_INT ) ) ) | (otherlv_3= 'filters' otherlv_4= '=' ( (lv_filters_5_0= RULE_INT ) ) ) )
            {
            // InternalNnDsl.g:347:2: ( (otherlv_0= 'kernel_size' otherlv_1= '=' ( (lv_ksize_2_0= RULE_INT ) ) ) | (otherlv_3= 'filters' otherlv_4= '=' ( (lv_filters_5_0= RULE_INT ) ) ) )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==22) ) {
                alt5=1;
            }
            else if ( (LA5_0==24) ) {
                alt5=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // InternalNnDsl.g:348:3: (otherlv_0= 'kernel_size' otherlv_1= '=' ( (lv_ksize_2_0= RULE_INT ) ) )
                    {
                    // InternalNnDsl.g:348:3: (otherlv_0= 'kernel_size' otherlv_1= '=' ( (lv_ksize_2_0= RULE_INT ) ) )
                    // InternalNnDsl.g:349:4: otherlv_0= 'kernel_size' otherlv_1= '=' ( (lv_ksize_2_0= RULE_INT ) )
                    {
                    otherlv_0=(Token)match(input,22,FOLLOW_12); 

                    				newLeafNode(otherlv_0, grammarAccess.getCOptionAccess().getKernel_sizeKeyword_0_0());
                    			
                    otherlv_1=(Token)match(input,23,FOLLOW_13); 

                    				newLeafNode(otherlv_1, grammarAccess.getCOptionAccess().getEqualsSignKeyword_0_1());
                    			
                    // InternalNnDsl.g:357:4: ( (lv_ksize_2_0= RULE_INT ) )
                    // InternalNnDsl.g:358:5: (lv_ksize_2_0= RULE_INT )
                    {
                    // InternalNnDsl.g:358:5: (lv_ksize_2_0= RULE_INT )
                    // InternalNnDsl.g:359:6: lv_ksize_2_0= RULE_INT
                    {
                    lv_ksize_2_0=(Token)match(input,RULE_INT,FOLLOW_2); 

                    						newLeafNode(lv_ksize_2_0, grammarAccess.getCOptionAccess().getKsizeINTTerminalRuleCall_0_2_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCOptionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"ksize",
                    							lv_ksize_2_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalNnDsl.g:377:3: (otherlv_3= 'filters' otherlv_4= '=' ( (lv_filters_5_0= RULE_INT ) ) )
                    {
                    // InternalNnDsl.g:377:3: (otherlv_3= 'filters' otherlv_4= '=' ( (lv_filters_5_0= RULE_INT ) ) )
                    // InternalNnDsl.g:378:4: otherlv_3= 'filters' otherlv_4= '=' ( (lv_filters_5_0= RULE_INT ) )
                    {
                    otherlv_3=(Token)match(input,24,FOLLOW_12); 

                    				newLeafNode(otherlv_3, grammarAccess.getCOptionAccess().getFiltersKeyword_1_0());
                    			
                    otherlv_4=(Token)match(input,23,FOLLOW_13); 

                    				newLeafNode(otherlv_4, grammarAccess.getCOptionAccess().getEqualsSignKeyword_1_1());
                    			
                    // InternalNnDsl.g:386:4: ( (lv_filters_5_0= RULE_INT ) )
                    // InternalNnDsl.g:387:5: (lv_filters_5_0= RULE_INT )
                    {
                    // InternalNnDsl.g:387:5: (lv_filters_5_0= RULE_INT )
                    // InternalNnDsl.g:388:6: lv_filters_5_0= RULE_INT
                    {
                    lv_filters_5_0=(Token)match(input,RULE_INT,FOLLOW_2); 

                    						newLeafNode(lv_filters_5_0, grammarAccess.getCOptionAccess().getFiltersINTTerminalRuleCall_1_2_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCOptionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"filters",
                    							lv_filters_5_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCOption"


    // $ANTLR start "entryRuleLOptions"
    // InternalNnDsl.g:409:1: entryRuleLOptions returns [EObject current=null] : iv_ruleLOptions= ruleLOptions EOF ;
    public final EObject entryRuleLOptions() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLOptions = null;


        try {
            // InternalNnDsl.g:409:49: (iv_ruleLOptions= ruleLOptions EOF )
            // InternalNnDsl.g:410:2: iv_ruleLOptions= ruleLOptions EOF
            {
             newCompositeNode(grammarAccess.getLOptionsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLOptions=ruleLOptions();

            state._fsp--;

             current =iv_ruleLOptions; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLOptions"


    // $ANTLR start "ruleLOptions"
    // InternalNnDsl.g:416:1: ruleLOptions returns [EObject current=null] : (otherlv_0= '(' ( (lv_option_1_0= ruleLOption ) )? (otherlv_2= ',' ( (lv_option_3_0= ruleLOption ) ) )* otherlv_4= ')' ) ;
    public final EObject ruleLOptions() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_option_1_0 = null;

        EObject lv_option_3_0 = null;



        	enterRule();

        try {
            // InternalNnDsl.g:422:2: ( (otherlv_0= '(' ( (lv_option_1_0= ruleLOption ) )? (otherlv_2= ',' ( (lv_option_3_0= ruleLOption ) ) )* otherlv_4= ')' ) )
            // InternalNnDsl.g:423:2: (otherlv_0= '(' ( (lv_option_1_0= ruleLOption ) )? (otherlv_2= ',' ( (lv_option_3_0= ruleLOption ) ) )* otherlv_4= ')' )
            {
            // InternalNnDsl.g:423:2: (otherlv_0= '(' ( (lv_option_1_0= ruleLOption ) )? (otherlv_2= ',' ( (lv_option_3_0= ruleLOption ) ) )* otherlv_4= ')' )
            // InternalNnDsl.g:424:3: otherlv_0= '(' ( (lv_option_1_0= ruleLOption ) )? (otherlv_2= ',' ( (lv_option_3_0= ruleLOption ) ) )* otherlv_4= ')'
            {
            otherlv_0=(Token)match(input,19,FOLLOW_14); 

            			newLeafNode(otherlv_0, grammarAccess.getLOptionsAccess().getLeftParenthesisKeyword_0());
            		
            // InternalNnDsl.g:428:3: ( (lv_option_1_0= ruleLOption ) )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( ((LA6_0>=25 && LA6_0<=26)) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalNnDsl.g:429:4: (lv_option_1_0= ruleLOption )
                    {
                    // InternalNnDsl.g:429:4: (lv_option_1_0= ruleLOption )
                    // InternalNnDsl.g:430:5: lv_option_1_0= ruleLOption
                    {

                    					newCompositeNode(grammarAccess.getLOptionsAccess().getOptionLOptionParserRuleCall_1_0());
                    				
                    pushFollow(FOLLOW_10);
                    lv_option_1_0=ruleLOption();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getLOptionsRule());
                    					}
                    					add(
                    						current,
                    						"option",
                    						lv_option_1_0,
                    						"org.xtext.example.nndsl.NnDsl.LOption");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalNnDsl.g:447:3: (otherlv_2= ',' ( (lv_option_3_0= ruleLOption ) ) )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==20) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalNnDsl.g:448:4: otherlv_2= ',' ( (lv_option_3_0= ruleLOption ) )
            	    {
            	    otherlv_2=(Token)match(input,20,FOLLOW_15); 

            	    				newLeafNode(otherlv_2, grammarAccess.getLOptionsAccess().getCommaKeyword_2_0());
            	    			
            	    // InternalNnDsl.g:452:4: ( (lv_option_3_0= ruleLOption ) )
            	    // InternalNnDsl.g:453:5: (lv_option_3_0= ruleLOption )
            	    {
            	    // InternalNnDsl.g:453:5: (lv_option_3_0= ruleLOption )
            	    // InternalNnDsl.g:454:6: lv_option_3_0= ruleLOption
            	    {

            	    						newCompositeNode(grammarAccess.getLOptionsAccess().getOptionLOptionParserRuleCall_2_1_0());
            	    					
            	    pushFollow(FOLLOW_10);
            	    lv_option_3_0=ruleLOption();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getLOptionsRule());
            	    						}
            	    						add(
            	    							current,
            	    							"option",
            	    							lv_option_3_0,
            	    							"org.xtext.example.nndsl.NnDsl.LOption");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

            otherlv_4=(Token)match(input,21,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getLOptionsAccess().getRightParenthesisKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLOptions"


    // $ANTLR start "entryRuleLOption"
    // InternalNnDsl.g:480:1: entryRuleLOption returns [EObject current=null] : iv_ruleLOption= ruleLOption EOF ;
    public final EObject entryRuleLOption() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLOption = null;


        try {
            // InternalNnDsl.g:480:48: (iv_ruleLOption= ruleLOption EOF )
            // InternalNnDsl.g:481:2: iv_ruleLOption= ruleLOption EOF
            {
             newCompositeNode(grammarAccess.getLOptionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLOption=ruleLOption();

            state._fsp--;

             current =iv_ruleLOption; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLOption"


    // $ANTLR start "ruleLOption"
    // InternalNnDsl.g:487:1: ruleLOption returns [EObject current=null] : ( (otherlv_0= 'activation' otherlv_1= '=' ( (lv_actFct_2_0= RULE_ACTIVATION ) ) ) | (otherlv_3= 'use_bias' otherlv_4= '=' ( (lv_useBias_5_0= RULE_BOOLEAN ) ) ) ) ;
    public final EObject ruleLOption() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_actFct_2_0=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token lv_useBias_5_0=null;


        	enterRule();

        try {
            // InternalNnDsl.g:493:2: ( ( (otherlv_0= 'activation' otherlv_1= '=' ( (lv_actFct_2_0= RULE_ACTIVATION ) ) ) | (otherlv_3= 'use_bias' otherlv_4= '=' ( (lv_useBias_5_0= RULE_BOOLEAN ) ) ) ) )
            // InternalNnDsl.g:494:2: ( (otherlv_0= 'activation' otherlv_1= '=' ( (lv_actFct_2_0= RULE_ACTIVATION ) ) ) | (otherlv_3= 'use_bias' otherlv_4= '=' ( (lv_useBias_5_0= RULE_BOOLEAN ) ) ) )
            {
            // InternalNnDsl.g:494:2: ( (otherlv_0= 'activation' otherlv_1= '=' ( (lv_actFct_2_0= RULE_ACTIVATION ) ) ) | (otherlv_3= 'use_bias' otherlv_4= '=' ( (lv_useBias_5_0= RULE_BOOLEAN ) ) ) )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==25) ) {
                alt8=1;
            }
            else if ( (LA8_0==26) ) {
                alt8=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // InternalNnDsl.g:495:3: (otherlv_0= 'activation' otherlv_1= '=' ( (lv_actFct_2_0= RULE_ACTIVATION ) ) )
                    {
                    // InternalNnDsl.g:495:3: (otherlv_0= 'activation' otherlv_1= '=' ( (lv_actFct_2_0= RULE_ACTIVATION ) ) )
                    // InternalNnDsl.g:496:4: otherlv_0= 'activation' otherlv_1= '=' ( (lv_actFct_2_0= RULE_ACTIVATION ) )
                    {
                    otherlv_0=(Token)match(input,25,FOLLOW_12); 

                    				newLeafNode(otherlv_0, grammarAccess.getLOptionAccess().getActivationKeyword_0_0());
                    			
                    otherlv_1=(Token)match(input,23,FOLLOW_16); 

                    				newLeafNode(otherlv_1, grammarAccess.getLOptionAccess().getEqualsSignKeyword_0_1());
                    			
                    // InternalNnDsl.g:504:4: ( (lv_actFct_2_0= RULE_ACTIVATION ) )
                    // InternalNnDsl.g:505:5: (lv_actFct_2_0= RULE_ACTIVATION )
                    {
                    // InternalNnDsl.g:505:5: (lv_actFct_2_0= RULE_ACTIVATION )
                    // InternalNnDsl.g:506:6: lv_actFct_2_0= RULE_ACTIVATION
                    {
                    lv_actFct_2_0=(Token)match(input,RULE_ACTIVATION,FOLLOW_2); 

                    						newLeafNode(lv_actFct_2_0, grammarAccess.getLOptionAccess().getActFctACTIVATIONTerminalRuleCall_0_2_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getLOptionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"actFct",
                    							lv_actFct_2_0,
                    							"org.xtext.example.nndsl.NnDsl.ACTIVATION");
                    					

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalNnDsl.g:524:3: (otherlv_3= 'use_bias' otherlv_4= '=' ( (lv_useBias_5_0= RULE_BOOLEAN ) ) )
                    {
                    // InternalNnDsl.g:524:3: (otherlv_3= 'use_bias' otherlv_4= '=' ( (lv_useBias_5_0= RULE_BOOLEAN ) ) )
                    // InternalNnDsl.g:525:4: otherlv_3= 'use_bias' otherlv_4= '=' ( (lv_useBias_5_0= RULE_BOOLEAN ) )
                    {
                    otherlv_3=(Token)match(input,26,FOLLOW_12); 

                    				newLeafNode(otherlv_3, grammarAccess.getLOptionAccess().getUse_biasKeyword_1_0());
                    			
                    otherlv_4=(Token)match(input,23,FOLLOW_17); 

                    				newLeafNode(otherlv_4, grammarAccess.getLOptionAccess().getEqualsSignKeyword_1_1());
                    			
                    // InternalNnDsl.g:533:4: ( (lv_useBias_5_0= RULE_BOOLEAN ) )
                    // InternalNnDsl.g:534:5: (lv_useBias_5_0= RULE_BOOLEAN )
                    {
                    // InternalNnDsl.g:534:5: (lv_useBias_5_0= RULE_BOOLEAN )
                    // InternalNnDsl.g:535:6: lv_useBias_5_0= RULE_BOOLEAN
                    {
                    lv_useBias_5_0=(Token)match(input,RULE_BOOLEAN,FOLLOW_2); 

                    						newLeafNode(lv_useBias_5_0, grammarAccess.getLOptionAccess().getUseBiasBOOLEANTerminalRuleCall_1_2_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getLOptionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"useBias",
                    							lv_useBias_5_0,
                    							"org.xtext.example.nndsl.NnDsl.BOOLEAN");
                    					

                    }


                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLOption"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000008010L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000060000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000001700000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000300000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000001400000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000006300000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000006000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000000080L});

}